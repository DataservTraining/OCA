package application;

public class Start {

	public static void main(String[] args) {
		int[][] array = new int[5][2];
		
		for(int zeile = 0; zeile < array.length; ++ zeile) {
			for(int spalte = 0; spalte < array[0].length; ++spalte) {
				array[zeile][spalte] = (int) (Math.random() * 100 + 1); 
			}
		}
		
		for(int[] zeile : array) {
			for(int spalte : zeile) {
				System.out.print(spalte + ",");
			}
			System.out.println();
		}
		
		System.out.println("====================================");
		int[][] array2 = new int[5][];
		for(int index = 0; index < array2.length; ++index) {
			int laenge = (int) (Math.random() * 10 + 1);
			System.out.println("L�nge: " + laenge);
			array2[index] = new int[laenge];
		}
		
		for(int zeile = 0; zeile < array2.length; ++zeile) {
			for(int spalte = 0; spalte < array2[zeile].length; ++spalte) {
				array2[zeile][spalte] = (int) (Math.random() * 100 + 1); 
			}
		}
		
		for(int[] zeile : array2) {
			for(int spalte : zeile) {
				System.out.print(spalte + ",");
			}
			System.out.println();
		}
		
		int[]     array3 = {23, 45, 56, 7, 12};
		int[][]   array4 = {{2, 1}, {31, 10, 6, 57}, {56, 78, 56, 9, 1}};
		int[][][] array5 = {{{1,2}, {3, 4, 5}}, {{6, 7, 8}, {9}, {10, 11}}, {{78}}};
		System.out.println(array5[1][0][2]);

	}

}
