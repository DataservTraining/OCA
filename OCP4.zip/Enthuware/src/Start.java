
class A{
	public A() {
		System.out.println("KA");
	}
	final int x = 10;
	
	void doIt() {
		System.out.println("A");
	}
}

class B extends A{
	
}

public class Start extends A{
	int x = 20;
	public static void main(String[] args) {
		Start s = new Start();
		System.out.println(((A)s).x);
		s.doIt();
		B b = new B();
	}
	
	void doIt() {
//		super.doIt();
		System.out.println("Start");
	}

}
