package a;

public class AccessTest {
int a;
private int b;
protected void c(){ }
public int d(){  return 0; }
}


