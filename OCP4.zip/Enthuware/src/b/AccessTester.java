package b;

import a.AccessTest;

public class AccessTester extends AccessTest{
    public static void main(String[] args) {
        AccessTest ref = new AccessTest();
        ref.d();
        
        char ch = 'A';
        
        switch(ch) {
        case 'A':
        }

    }
}