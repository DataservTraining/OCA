package application;

import java.util.ArrayList;
import java.util.List;

public enum Coffeesize { BIG("Big",8), 
	HUGE("Huge", 10),
	OVERWHELMING("Overwhelming", 16){
	@Override
	public String getLidCode() {
		return "A";
	}
};
	private int size = 10;
	private String name;
	
	private Coffeesize(int size) {
		this.size = size;
	}
	private Coffeesize(String name, int size) {
		this.size = size;
	}
	
	public String getLidCode() {
		return "B";
	}
	
	public void print() {
		System.out.println(getLidCode());
	}
	
	public int getSize() {return size;}
	public String getName() {
		return name;
	}
	
	public static List<Coffeesize> getAllElements(){
		List<Coffeesize> liste = new ArrayList<>();
		liste.add(BIG);
		liste.add(HUGE);
		liste.add(OVERWHELMING);
		return liste;
	}
	
}
