package application;

public enum Operationen {
	ADDIEREN{

		@Override
		public double operate(double a, double b) {
			return a + b;
		}},
	SUBTRAHIEREN{public double operate(double a, double b) {return a - b;}},
	MULTIPLIZIEREN{public double operate(double a, double b) {return a * b;}},
	DIVIDIEREN{public double operate(double a, double b) {return a / b;}};
	
	public abstract double operate(double a, double b);
}

interface Y{
	
}

interface X extends Y{
	
}
