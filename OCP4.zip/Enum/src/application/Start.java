package application;
import static application.Coffeesize.*;

public class Start {
//	public enum Coffeesize2 { SMALL, HUGE,OVERWHELMING}
	public static void main(String[] args) {
		
		Coffeesize cs = Coffeesize.BIG;
		
		System.out.println(cs);
		System.out.println(cs.getSize());
		cs = OVERWHELMING;
		System.out.println(cs);
		System.out.println(cs.getSize());
		
		System.out.println(Coffeesize.valueOf("BIG"));
		Coffeesize[] array = Coffeesize.values();
		for(Coffeesize s : array) {
			System.out.print(s + "\t");
			System.out.println(s.ordinal());
		}
		System.out.println("****************************");
		Coffeesize.getAllElements().forEach(Coffeesize::print);

		Operationen ops = Operationen.MULTIPLIZIEREN;
		System.out.println(ops.operate(3, 4));
	}

}
