package application;

import java.io.IOException;

import entities.Mitarbeiter;
import entities.Person;

public class Start {

	public static void main(String[] args) {
		Person[] personen = new Person[5];
		personen[0] = new Person("Person 1");
		personen[1] = new Mitarbeiter("Mitarbeiter 1", 2343.78);
		personen[2] = new Person("Person 3");
		personen[3] = new Mitarbeiter("Mitarbeiter 2", 2343.78);
		personen[4] = new Person("Person 5");
		
		for(int index = 0; index < personen.length; ++index) {
			try {
				personen[index].show();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		Integer i1 = 1;
		Byte b1 = 1;
		
		int a = 5;
		
		int x = new Integer(a);
		
		int erg = x + a;

	}

}
