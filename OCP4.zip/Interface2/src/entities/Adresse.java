package entities;

public class Adresse {
	private String ort;
}
