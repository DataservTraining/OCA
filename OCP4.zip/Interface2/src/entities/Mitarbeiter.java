package entities;

import java.sql.SQLException;

public class Mitarbeiter extends Person {
	private double gehalt;

	public Mitarbeiter(String name, double gehalt) {
		super(name);
		this.gehalt = gehalt;
	}

	@Override
	public void show() throws ArrayIndexOutOfBoundsException{
//		super.show();
		System.out.println(getName());
		System.out.println(gehalt);
	}
	
	
}
