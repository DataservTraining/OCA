package entities;

import java.io.IOException;

public class Person extends Object {
	private String name = "";
	private Adresse adresse = new Adresse();
	private Person partner = new Person("");

	public Person(String name) {
		super();
		this.name = name;
	}
	
	
	
	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public Adresse getAdresse() {
		return adresse;
	}



	public void setAdresse(Adresse adresse) {
		this.adresse = adresse;
	}



	public Person getPartner() {
		return partner;
	}



	public void setPartner(Person partner) {
		this.partner = partner;
	}



	public void show() throws IOException{
		System.out.println(name);
	}
}
