package interfaces;

@FunctionalInterface
public interface InterfaceA {
	
	public static final int x = 10;
	
	public abstract int add(int a, int b);
	
	

}

@FunctionalInterface
interface InterfaceB{
	public abstract void test();
}


interface InterfaceC extends InterfaceA, InterfaceB{
	public abstract void test2();
	public abstract void test();
	// ab Java 8
	public default void test3() {
		System.out.println("public default void test3()");
	}
}

interface InterfaceD extends InterfaceA, InterfaceB{
	
	// ab Java 8
	public default void test3() {
		System.out.println("public default void test3()");
	}
	
	// ab Java 8
	public static void staticTest() {
		System.out.println("public static void staticTest()");
	}
}

abstract class Z implements InterfaceD{

	@Override
	public void test() {
		// TODO Auto-generated method stub
		
	}
	
}

class Y extends Z{

	@Override
	public int add(int a, int b) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}

class X implements InterfaceC, InterfaceD{
	
	
	
	public void test4(final int a) {
//		a = a * 5;
	}
	
	
	public int add(int a, int b){
		return a + b;
	}

	@Override
	public void test2() {
		System.out.println("public void test2()");
		
	}

	@Override
	public void test() {
		System.out.println("public void test()");
		
	}

	@Override
	public void test3() {
		InterfaceC.super.test3();
	}

	
	
	
}

