package interfaces;

public class Start {

	public static void main(String[] args) {
		X x = new X();
		int erg = x.add(2, 5);
		System.out.println(erg);
		x.test();
		x.test2();
		x.test3();
		
		InterfaceD.staticTest();
		
		
	}

}
