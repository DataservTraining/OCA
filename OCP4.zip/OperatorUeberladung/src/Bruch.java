
public class Bruch {
	private int zaehler;
	private int nenner;
	
	public Bruch operator+(Bruch b2){
		
	}
	
	public Bruch operator++(){ // Prefix
		zaehler += nenner;
		return this;
	}
	public Bruch operator++(int x){ // Postfix
		Bruch temp = new Bruch(this);
		zaehler += nenner;
		return temp;
	}

}
