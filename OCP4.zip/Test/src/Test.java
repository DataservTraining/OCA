import java.io.IOException;

public class Test {

	public static void main(String[] args) throws IOException {
		if(false) {
			throw new IOException();
		}
		
//		while(false) {
//			throw new IOException();
//		}

	}

}
