
public class X {
	private String str = "default";
	private int value = 17;
	
	X(String s){
		str = s;
	}
	
	X(int i) {
		value = i;
	}
	
	void print() {
		System.out.println(str + " " + value);
	}

	public static void main(String[] args) {
//	X x = new X("hello");
//	x.print();
		new X("hello").print();
		new X(92).print();

	}

}
