
public class Start {

	public static void main(String[] args) throws InterruptedException {
		System.out.println(Thread.currentThread().getName());
		System.out.println(Thread.currentThread().getState());
		
		UhrenThread uhr1 = new UhrenThread();
		uhr1.setName("Uhr 1: ");
		uhr1.setPriority(Thread.MIN_PRIORITY);
		
		UhrenRunnable uhr2Runnable = new UhrenRunnable();
		Thread uhr2 = new Thread(uhr2Runnable, "Uhr 2: ");
//		uhr1.setDaemon(true);
		uhr1.start();
		uhr2.start();
		for(int i = 1; i < 11; ++i) {
			System.out.println("Z�hler: " + i);
			Thread.sleep(500);
		}
//		uhr1.uhrAnhalten();
		uhr1.interrupt();
		uhr2.interrupt();
		Summierer summierer = new Summierer();
		Thread summiererThread = new Thread(summierer, "Summierer");
		summiererThread.start();
		for(int i = 1; i < 11; ++i) {
			System.out.println("Z�hler: " + i);
			Thread.sleep(10);
		}
		summiererThread.join();
		System.out.println("Summe: " + summierer.getSumme());

	}

}
