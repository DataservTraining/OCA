
public class Summierer implements Runnable{
	private int summe;

	@Override
	public void run() {
		for(int i = 1; i < 500; ++i) {
			summe += i;
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				return;
			}
		}
	}

	public int getSumme() {
		return summe;
	}
	
	

}
