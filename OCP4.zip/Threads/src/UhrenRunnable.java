import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class UhrenRunnable implements Runnable {
	private boolean running = true;

	@Override
	public void run() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss", Locale.GERMAN);
		while (running) {
			LocalTime time = LocalTime.now();
			System.out.println(Thread.currentThread().getName() + formatter.format(time));
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
//				e.printStackTrace();
				return;
			}

		}
	}

	public void uhrAnhalten() {
		running = false;
	}

}
