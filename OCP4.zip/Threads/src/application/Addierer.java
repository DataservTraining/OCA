package application;

public class Addierer implements Runnable{

	private int summe = 0;
	
	@Override
	public void run() {
		for(int i = 1; i < 50; ++i) {
			summe += i;
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Summe im Addierer: " + summe);
		
	}

	public int getSumme() {
		return summe;
	}

}
