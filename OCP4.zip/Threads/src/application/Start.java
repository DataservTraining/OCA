package application;

public class Start {

	public static void main(String[] args) {
		
		UhrenThread uhr1 = new UhrenThread("Uhr1");
		UhrenKlasse uhrenRunnable = new UhrenKlasse();
		Thread uhr2 = new Thread(uhrenRunnable, "Uhr2");
		uhr1.setDaemon(true);
		uhr1.start();
		uhr2.start();
		for(int i = 0; i < 20; ++i) {
			System.out.println("Z�hler " + i);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		uhr2.interrupt();
//		uhr1.stopUhr();
//		uhr1.interrupt();
	}

}
