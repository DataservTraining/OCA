package application;

public class StartSummierer {

	public static void main(String[] args) {
		Addierer adder = new Addierer();
		Thread  addiererThread = new Thread(adder);
		addiererThread.start();
		try {
			addiererThread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Summe in main():" + adder.getSumme());

	}

}
