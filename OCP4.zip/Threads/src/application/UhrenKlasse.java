package application;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class UhrenKlasse implements Runnable{
	private boolean running = true;
	@Override
	public void run() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
		LocalTime time = null;
		while(running) {
			time = LocalTime.now();
			System.out.println(Thread.currentThread().getName() + ": "  + formatter.format(time));
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				return;
			}
		}
	}

	
	public void stopUhr() {
		running = false;
	}
}
