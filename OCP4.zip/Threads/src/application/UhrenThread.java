package application;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class UhrenThread extends Thread{
	private boolean running = true;
	
	public UhrenThread() {
		
	}
	
	public UhrenThread(String name) {
		super(name);
	}
	
	@Override
	public void run() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
		LocalTime time = null;
		while(running) {
			time = LocalTime.now();
			System.out.println(Thread.currentThread().getName() + ": " + formatter.format(time));
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
//				e.printStackTrace();
				return;
			}
		}
	}

	
	public void stopUhr() {
		running = false;
	}
}
