package cowboyjim;

public class KauRunnable implements Runnable{

	@Override
	public void run() {
		while (true) {
			System.out.println("Schmatz");
			try {
				Thread.sleep(300);
			} catch (InterruptedException e) {
				return;
			}
		}
		
	}

}
