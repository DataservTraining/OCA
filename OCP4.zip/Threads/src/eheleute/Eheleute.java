package eheleute;

public class Eheleute extends Thread{
	
	private Konto konto;



	public Eheleute(String name, Konto konto) {
		super(name);
		this.konto = konto;

	}


	@Override
	public void run() {
		while(true) {
			synchronized (konto) {
				System.out.println(Thread.currentThread().getName() + " will 100 � abheben");
				
				konto.showSaldo();
				try {
					konto.abheben(100);
				} catch (NoMoneyException e) {
					System.out.println(e.getMessage());
					return;
				}
			}
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
