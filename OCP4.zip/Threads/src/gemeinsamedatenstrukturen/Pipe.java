package gemeinsamedatenstrukturen;

public class Pipe {
	private int index;
	private int[] feld = new int[4];
	

	public synchronized void write(int wert) {
		if(index == feld.length) {
			try {
				this.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		feld[index] = wert;
		++index;
		if(index == 1) {
			this.notifyAll();
		}
	}

	public synchronized int read() {
		if(index == 0) {
			try {
				this.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		int temp = feld[0];
		for (int i = 0; i < index - 1; ++i) {
			feld[i] = feld[i + 1];
		}
		--index;
		if(index == feld.length-1) {
			this.notifyAll();
		}
		return temp;
	}

	private Object monitor = new Object();
	
	public void write2(int wert) {
		synchronized (monitor) {
			feld[index] = wert;
			++index;
		}
	}

	public int read2() {
		int temp = 0;
		synchronized (monitor) {
			temp = feld[0];
			for (int i = 0; i < index - 1; ++i) {
				feld[i] = feld[i + 1];
			}
			--index;
		}
		return temp;
	}

}
