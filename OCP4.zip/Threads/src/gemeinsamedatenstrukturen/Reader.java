package gemeinsamedatenstrukturen;

public class Reader implements Runnable{
	private Pipe pipe;
	
	public Reader(Pipe pipe) {
		super();
		this.pipe = pipe;
	}

	@Override
	public void run() {
		int zahl;
		
		while((zahl = pipe.read()) != -1 ) {
			System.out.println("Reader gelesen: " + zahl);
			try {
				Thread.sleep(15);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}

}
