package gemeinsamedatenstrukturen;

public class Start {

	public static void main(String[] args) {
		Pipe pipe = new Pipe();
		Thread writer = new Thread(new Writer(pipe));
		Thread reader = new Thread(new Reader(pipe));
		writer.start();
		reader.start();
	}

}
