package gemeinsamedatenstrukturen;

public class Writer implements Runnable{
	private Pipe pipe;
	
		public Writer(Pipe pipe) {
		super();
		this.pipe = pipe;
	}

	@Override
	public void run() {
		for(int z = 1; z < 101; ++z) {
			pipe.write(z);
			
			System.out.println("Writer geschrieben: " + z);
			try {
				Thread.sleep(15);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		pipe.write(-1);
		
	}

}
