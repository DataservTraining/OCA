package gemeinsamerdatenzugriff2;

public class Reader extends Thread {
	private Pipe pipe;

	public Reader(Pipe pipe) {
		super();
		this.pipe = pipe;
	}
	
	public void run() {
		int zahl = 0;
		while(zahl != -1) {
			synchronized (pipe) {
				zahl = pipe.read();
				if(zahl != -1) System.out.println("gelesen: " + zahl);
			}
			
			//---------------------------------------
			try {
				Thread.sleep(15);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	

}
