package gemeinsamerdatenzugriff2;

public class Start {

	public static void main(String[] args) {
		Pipe pipe = new Pipe();
		Writer writer = new Writer(pipe);
		Reader reader = new Reader(pipe);
		
		reader.start();
		writer.start();

	}

}
