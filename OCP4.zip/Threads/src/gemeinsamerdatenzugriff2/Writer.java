package gemeinsamerdatenzugriff2;

public class Writer extends Thread{
	private Pipe pipe;
	
	public Writer(Pipe pipe) {
		this.pipe = pipe;
	}
	
	@Override
	public void run() {
		for(int zahl = 1; zahl < 101; ++zahl) {
			synchronized (pipe) {
				pipe.write(zahl);
				//--------------------------
				System.out.println("geschrieben: " + zahl);
			}
			try {
				Thread.sleep(15);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		pipe.write(-1);
	}
}
