
public class Start {
	private int x = 10;
	
	public void showX() {
		int x = 9;
		System.out.println(x);
	}

	public static void main(String[] args) {
		testVarArgs(3, 7, "", 'A', new Tier(), 9);
		testVarArgs(4, 8);
		double d1 = 3.4, d2 = 5.6;
		System.out.printf("Das Ergebnis der Division von %2$5.1f / %1$5.2f = %f\n", d1, d2, d1/d2);
		System.out.printf("Das Quadrat von %1$5.1f ^ %1$5.2f = %.2f\n", d1, d1*d1);
		String.format("", args);
	}

	public static void testVarArgs(int a, int c) {
		System.out.println("void testVarArgs(int a, int c): " + (a + c));
	}
	
	public static void testVarArgs(int a, Object... b) {
		double summe = a;
		for (int i = 0; i < b.length; ++i) {
			if (b[i] instanceof Integer) {
				summe += (Integer)b[i];
			}
		}

		System.out.println("void testVarArgs(int a, Object... b): " + summe);
	}

}
