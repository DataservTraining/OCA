package application;

interface InterfaceA{
	void doStuff();
	default short m3() {return 5;}
}

public class FinalTest implements InterfaceA{
	int a = 9;
	static int b = 2;
	
	void doStuff() {}

	public static void main(String[] args) {
//		System.out.println(a);
		System.out.println(b);
//		test();

	}
	
	public void test() {
		System.out.println(a);
		System.out.println(b);
	}

}
