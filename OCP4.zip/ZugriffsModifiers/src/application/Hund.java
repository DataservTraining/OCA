package application;

public class Hund {
	public void print() {
		Tier tier = new Tier();
//		System.out.println(tier.a);
		System.out.println(tier.b);
		System.out.println(tier.c);
		System.out.println(tier.d);
	}
}
