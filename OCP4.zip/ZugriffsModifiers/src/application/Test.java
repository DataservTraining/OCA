package application;

import tiere.AbstrakteKlasse;

public class Test {
	public static void main(String[] args) {
		Tier tier = new Tier();
		tier.print();
		Tier tier2 = new Tier();
		tier.print();
		Tier tier3 = new Tier();
		tier.print();
		tier.test(tier3);
		tier3.print();
		
//		AbstrakteKlasse klasse = new AbstrakteKlasse(); 
		
	}
}
