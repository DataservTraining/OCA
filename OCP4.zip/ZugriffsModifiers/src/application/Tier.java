package application;

public class Tier {
	private int a = 10;
	int b = 20;
	protected int c = 30;
	public int d = 40;
	
	public void print() {
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
	}
	
	public void test(final int a) {
//		a = a * 6;
	}

	public void test(final Tier tier) {
//		tier = new Tier();
		tier.a = 100;
	}

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}

	public int getD() {
		return d;
	}

	public void setD(int d) {
		this.d = d;
	}
	
	
}
