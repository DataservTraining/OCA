package tiere;

abstract public  class AbstrakteKlasse {
	public abstract void test();
}

class SubFromAbstractClass extends AbstrakteKlasse{

	@Override
	public void test() {
		// TODO Auto-generated method stub
		
	}
	
}
