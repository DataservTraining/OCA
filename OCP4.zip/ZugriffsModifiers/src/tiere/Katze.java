package tiere;

import application.Tier;

public class Katze extends Tier{
	private int x = 1; 
	public void print() {
		Tier tier = new Tier();
//		System.out.println(tier.a);
//		System.out.println(tier.b);
		System.out.println(c);
//		System.out.println(tier.c);
		System.out.println(tier.d);
	}
}
