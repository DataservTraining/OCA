package application;

//import db.DbInterface;
import db.*;
import entities.Person;

public class Start {

	public static void main(String[] args) {
		Person pers = new Person();
		DbInterface db = new MySQLImpl();
		db.speichernPerson(pers);
		db.aendernPerson(pers);
		Person gefunden = db.suchePerson(12);
	}

}
