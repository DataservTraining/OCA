package db;

import entities.Person;

public interface DbInterface {
	public abstract void speichernPerson(Person p);
	void loeschenPerson(Person p);
	void aendernPerson(Person p);
	Person suchePerson(int id);
	

}
