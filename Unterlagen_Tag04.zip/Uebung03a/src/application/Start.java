package application;

public class Start {

	public static void main(String[] args) {
		Rechteck a = new Rechteck(10.4, 5.2);
		
		a.showInfo();

	}

}
