package entities;

public abstract class MyDocument {
	protected abstract void save();
}
