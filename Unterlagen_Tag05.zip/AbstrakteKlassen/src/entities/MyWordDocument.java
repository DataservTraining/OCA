package entities;

public class MyWordDocument extends MyDocument{

	@Override
	protected void save() {
		System.out.println("MyWordDocument gespeichert");
	}

}
