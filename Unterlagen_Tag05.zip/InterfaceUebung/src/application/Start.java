package application;

public class Start {

	public static void main(String[] args) {
		Zoo zoo = new Zoo();
		Transportunternehmen transportunternehmen = new Transportunternehmen();
		Lasttier esel = new Lasttier();
		System.out.println(esel);
		
		zoo.fuettern(esel);
		
		System.out.println(esel);
		
		transportunternehmen.beladen(esel, 80);
		
		System.out.println(esel);

	}

}
