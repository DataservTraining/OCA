package application;

import entities.Mitarbeiter;
import entities.Person;

public class Start {

	public static void main(String[] args) {
		Person person1;
		person1 = new Person();
		person1.setVorname(new String("Willi"));
		person1.setNachname("Wuff");
		person1.setAlter(15);
		System.out.println(person1);
		Person person2 = new Person("Donald", "Duck", 6);
		System.out.println(person2);
		person2.show();
		
		Mitarbeiter mitarbeiter1 = new Mitarbeiter("Hans", "Meier", 45, 131234, 10, "Testgasse", "K�ln");
		System.out.println(mitarbeiter1);
		mitarbeiter1.show();
		System.out.println("----------------------------------------");
		Person person3 = new Mitarbeiter("Franz", "Schmitz", 38, 34535, 5, "Musterweg", "M�nchen");
		person3.show();
		
		//Mitarbeiter mitarbeiter2 = new Person();
		ausgabe(person1);
		ausgabe(mitarbeiter1);
		
	}
	
	public static void ausgabe(Person p) {
		System.out.println("================================");
		p.show();
		System.out.println("********************************");
	}

}
