package entities;

public class MyWordApplication extends MyApplication{

	@Override
	protected MyDocument createDocument() {
		return new MyWordDocument();
	}

}
