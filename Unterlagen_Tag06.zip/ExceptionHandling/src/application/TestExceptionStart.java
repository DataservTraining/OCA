package application;

import java.io.FileNotFoundException;

public class TestExceptionStart {

	public static void main(String[] args) {
		TestException ex = new TestExceptionExtended();
		
		try {
			ex.test();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
