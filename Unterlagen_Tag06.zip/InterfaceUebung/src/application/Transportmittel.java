package application;

public interface Transportmittel {
	public void erhoeheGewicht(double kg);
}
