package application;

public class Zoo {
	
	public void fuettern(Lebewesen l) {
		l.sattwerden();
	}

}
