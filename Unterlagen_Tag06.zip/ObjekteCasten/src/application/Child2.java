package application;

public class Child2 extends Parent {

	@Override
	public void test() {
		System.out.println("Child2.test()");
	}
	public void test1() {
		System.out.println("Child2.test()");
	}


}
