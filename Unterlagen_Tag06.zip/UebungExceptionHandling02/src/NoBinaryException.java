
public class NoBinaryException extends RuntimeException {

	public NoBinaryException() {
		super();
	}
	
	public NoBinaryException(String s) {
		super(s);
	}
	
	public NoBinaryException(String s, int pos) {
		super(s + ": Fehler an Position " + pos);
	}
	
	
}
