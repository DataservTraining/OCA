package application;




public class Start {

	public static void main(String[] args) {
		int x = 9;
		String name = "";
		MyIntegerWrapper wrapper = new MyIntegerWrapper(x);
		show(wrapper);
		
	}
	
	public static void show(Object o) {
		System.out.println(o);
	}

}


class MyIntegerWrapper extends Object{
	private int value;
	
	public MyIntegerWrapper(int value) {
		this.value = value;
	}
	
	public String toString() {
		return Integer.toString(value);
	}
}