package entities;

public class Start {

	public static void main(String[] args) {
		Person p = new Person("Musterweg", "Musterstadt", "Hans", "Meier", 34);
		Printer printer = new Printer();
//		printer.print(p);
		
		printer.print(p.getVorname(), p.getNachname(), p.getAlter(), 
				p.getAdresse().getStrasse(), p.getAdresse().getOrt());

	}

}
