package application;

import java.io.IOException;

public class DateiTestStart {

	public static void main(String[] args) {
		String datei = "text.txt";
		
		try {
			DateiBearbeitung.writeFile(datei, "Hallo Welt");
			long start = System.currentTimeMillis();
			String inhalt = DateiBearbeitung.readFile(datei);
			long end = System.currentTimeMillis();
			System.out.println(inhalt);
			System.out.println("Dauer: " + (end - start));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
