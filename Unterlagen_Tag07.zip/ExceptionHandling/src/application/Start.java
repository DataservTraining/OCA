package application;

public class Start {

	public static void main(String[] args) {
		int x = 8, y = 0, erg = 0;
		Object o = new Object();
		int[] array = {12, 34, 56, 34, 7};
		
		//erg = x / y;
		
		
		try {
			erg = x / y;
			System.out.println(erg);
			Thread.sleep(500);
			System.out.println(o.hashCode());
		}  
		catch (ArithmeticException e) {
			System.out.println("Fehler:");
			System.out.println(e.getMessage());
			System.out.println(e.getCause());
			System.out.println("StackTrace: ");
			e.printStackTrace();
//			return;
			System.exit(0);
		} catch ( NullPointerException e) {
			System.out.println(e.getMessage());
		} catch (RuntimeException e) {
			e.printStackTrace();
		} catch(InterruptedException e) {
			System.out.println("InterruptedException");
		} catch(Exception e) {
			System.out.println("Exception");
		} finally {
			System.out.println("finally");
		}
		

		System.out.println("Ende");
	}

}
