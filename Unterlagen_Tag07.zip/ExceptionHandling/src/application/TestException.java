package application;

import java.io.FileNotFoundException;

public class TestException {
	
	public void test() throws FileNotFoundException {
		int x = 10;
		if(x == 10) {
			throw new FileNotFoundException("aus TestException.test()");
		}
	}

}
