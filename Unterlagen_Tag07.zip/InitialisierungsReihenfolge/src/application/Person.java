package application;

public class Person extends Lebewesen {
	private static final int Final;
	private static int anzahl;
	private int alter;
	private String name ="direkt";
	
	static {
		Final = 12;
		System.out.println("Final initialisiert");
	}
	
	{
		name = "Initialisierung";
		
	}

	public Person() {
		this(10, "Name aus Standardkonstruktor");
		//name = "Standardkonstruktor";
	}

	public Person(String name) {
		this(10, name);
	}
	
	public Person(int alter, String name) {
		super(alter);
		anzahl++;
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	protected void finalize() {
		anzahl--;
	}
	
//	{
//		System.out.println("zweiter Initialisierungsblock");
//	}
	
	public static int getAnzahl() {
		return anzahl;
	}

}
