package db;

import entities.Person;

public class MySQLImpl implements DbInterface{

	@Override
	public void speichernPerson(Person p) {
		System.out.println("Person in MySQL gespeichert");
		
	}

	@Override
	public void loeschenPerson(Person p) {
		System.out.println("Person aus MySQL gel�scht");
		
	}

	@Override
	public void aendernPerson(Person p) {
		System.out.println("Person auf MySQL ge�ndert");
		
	}

	@Override
	public Person suchePerson(int id) {
		System.out.println("Person in MySQL gefunden");
		return new Person();
	}

}
