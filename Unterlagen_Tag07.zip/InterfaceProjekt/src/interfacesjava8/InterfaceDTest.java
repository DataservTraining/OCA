package interfacesjava8;

public class InterfaceDTest implements D{

	@Override
	public void t1() {
		System.out.println("public void t1()");
		
	}

	@Override
	public void t5() {
		System.out.println("public void t5()");
		
	}

	@Override
	public void t6() {
		System.out.println("public void t6()");
		
	}

}
