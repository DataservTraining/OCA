package app;

public class Start {

	public static void main(String[] args) {
		int x = 10;
		
		String text = (("x+y = " + 9) + 3) + " ";
		text = "Hallo";
		String komplett = text.concat(" Welt");
		
		System.out.println(komplett);
		
		switch(x) {
		case 1: System.out.println("1");
				break;
		case 2: System.out.println("2");
		break;
		default:
			System.out.println("default");
			break;
		case 3: System.out.println("3");
		break;
		case 4: System.out.println("4");
		break;
		
		
		}
		

	}

}
