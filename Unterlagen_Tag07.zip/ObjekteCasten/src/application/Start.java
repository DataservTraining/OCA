package application;

public class Start {

	public static void main(String[] args) {
		Parent parent = new Parent();
		parent.test();

		Parent child1 = new Child1();
		
		if (parent instanceof Child1) {
			Child1 child1a = (Child1) parent;
			child1a.test1();
		}

		Child2 child2 = new Child2();
		
		parent = child2;
		
		Child1 child1b = (Child1) child2;
	}

}
