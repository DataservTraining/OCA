package application;

public class Rechteck {
	private double laenge;
	private double breite;
	
	public Rechteck() {
		this(1, 1);
	}
	
	public Rechteck(double seitenlaenge) {
		this(seitenlaenge, seitenlaenge);
	}
	
	public Rechteck(double laenge, double breite) {
		super();
		setLaenge(laenge);
		setBreite(breite);
	}

	public double getLaenge() {
		return laenge;
	}

	public void setLaenge(double laenge) {
		if(laenge < 0) {
			System.out.println("Wert f�r die L�nge ung�ltig: " + laenge);
			return;
		}
		this.laenge = laenge;
	}

	public double getBreite() {
		return breite;
	}

	public void setBreite(double breite) {
		if(breite < 0) {
			System.out.println("Wert f�r die Breite ung�ltig: " + breite);
			return;
		}

		this.breite = breite;
	}
	
	
	public void show() {
		System.out.println("L�nge: " + laenge);
		System.out.println("Breite: " + breite);
	}
	
}
