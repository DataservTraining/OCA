package application;

public class Start {

	public static void main(String[] args) {
		Rechteck r1 = new Rechteck();
		Rechteck r2 = new Rechteck(34.5);
		Rechteck r3 = new Rechteck(23.6, 67.5);
		
		r1.show();
		System.out.println("\n========================\n");
		r2.show();
		System.out.println("\n========================\n");
		r3.show();
		System.out.println("\n========================\n");
	}

}
