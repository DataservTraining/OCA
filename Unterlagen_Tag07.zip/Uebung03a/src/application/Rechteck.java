package application;



public class Rechteck {
	
	private double laenge;
	private double breite;
	
	public Rechteck() {
		this(1.0, 1.0);
	}
	
	public Rechteck(double seitenlaenge) {
		this(seitenlaenge, seitenlaenge);
	}
	
	public Rechteck(double laenge, double breite) {
		this.laenge = laenge;
		this.breite = breite;
	}
	
	public double getLaenge() {
		return this.laenge;
	}
	
	public double getBreite() {
		return this.breite;
	}
	
	public void setLaenge(double laenge) {
		if(laenge < 0) {
			System.out.println("ung�ltiger WErt f�r die L�nge: " + laenge);
			return;
		}
		this.laenge = laenge;
	}
	
	public void setBreite(double breite) {
		this.breite = breite;
	}

	public void showInfo() {
		System.out.println("Laenge: " + laenge);
		System.out.println("Breite: " + breite);
	}
}
