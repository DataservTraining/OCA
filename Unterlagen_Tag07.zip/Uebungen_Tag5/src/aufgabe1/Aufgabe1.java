package aufgabe1;

import java.util.Scanner;

public class Aufgabe1 {

	public static void main(String[] args) {
		int summe = 0;
		int zaehler = 0;
		Scanner scanner = new Scanner(System.in);
		int zahl = scanner.nextInt();
		while(zahl != 0) {
			summe += zahl;
			++zaehler;
			zahl = scanner.nextInt();
		}
		System.out.println("Summe = " + summe);
		if(zaehler != 0) {
			System.out.println("Der Mittelwert ist gleich " + ((double) summe / zaehler));
		} else {
			System.out.println("es wurde nur die 0 eingegeben");
		}

		scanner.close();
	}

}
