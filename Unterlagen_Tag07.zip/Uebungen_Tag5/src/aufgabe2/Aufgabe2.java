package aufgabe2;

import java.util.Scanner;

public class Aufgabe2 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Bitte Zahl eingeben: ");
		int zahl = scanner.nextInt();
		int ergebnis = zahl;
		for(int faktor = zahl - 1; faktor > 0; --faktor) {
			ergebnis *= faktor;
		}
		
		System.out.println("Die Fakult�t von " + zahl + " ist gleich " + ergebnis);
		

		scanner.close();
	}

}
