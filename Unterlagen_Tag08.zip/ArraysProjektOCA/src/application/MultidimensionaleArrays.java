package application;

public class MultidimensionaleArrays {

	public static void main(String[] args) {
		int groesse = 0;
		int[][] array1 = {{1,2}, {2, 8, 4}, {1,6,9,34}};
		int array2[][] = new int[3][2];
		int[] array3[]  = new int[groesse][];
//		System.out.println(array3[0]);
		for(int i = 0; i < array3.length; ++i) {
			array3[i] = new int[(int)(Math.random()*30+1)];
		}
		
		for(int zeile = 0; zeile < array3.length; ++zeile) {
			for(int spalte = 0; spalte < array3[zeile].length; ++spalte)
			array3[zeile][spalte] = (int)(Math.random()*100+1);
		}
		
		for(int[] z : array3) {
			for(int w : z) {
				System.out.print(w + ", ");
			}
			System.out.println();	
		}
		
		int[][][] array5 = {{{2,7}},{{0,2,1,8},{123, 53, 76},{12, 5, 0}},{{7,5,2}}};

		System.out.println(array5[1][1][2]);
		
		for(int[][]  d1 : array5) {
			System.out.print("{");
			for(int[] d2 : d1) {
				System.out.print("{");
				for(int d3 : d2) {
					System.out.print(d3 + ", ");
				}
				System.out.print("}");
			}
			System.out.println("}");
		}
	}

}
