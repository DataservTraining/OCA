package application;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class DateiBearbeitung {
	
	public static String readFile(String fileName) throws IOException, FileNotFoundException {
		String zeile;
		BufferedReader in = new BufferedReader(new FileReader(fileName));
		StringBuilder text = new StringBuilder("");
		while((zeile = in.readLine()) != null) {
			text.append(zeile);
			text.append('\n');
		}
		in.close();
		return text.toString();
	}
	
	public static void writeFile(String fileName, String text) throws IOException{
			PrintWriter out = new PrintWriter(new FileWriter(fileName));
			for(int zeile = 0; zeile < 100_000; ++zeile) {
				out.println(text);
			}
			out.close();
	}

}
