package application;

import java.util.Scanner;

public class Rechteck {
	private double laenge;
	private double breite;
	
	public Rechteck() {
		this(1, 1);
	}
	
	public Rechteck(double seitenlaenge) {
		this(seitenlaenge, seitenlaenge);
	}
	
	public Rechteck(double laenge, double breite) {
		super();
		setLaenge(laenge);
		setBreite(breite);
		
	}

	public double getLaenge() {
		return laenge;
	}

	public void setLaenge(double laenge) {
		if(laenge < 0) {
//			throw new IllegalArgumentException("Wert f�r die L�nge ung�ltig: " + laenge);
			throw new FalscheSeitenLaengeException("Wert f�r die L�nge ung�ltig: " + laenge, "setLaenge()", 31, 1536);
		}
	
		this.laenge = laenge;
	}

	public double getBreite() {
		return breite;
	}

	public void setBreite(double breite) {
		if(breite < 0) {
			throw new IllegalArgumentException("Wert f�r die Breite ung�ltig: " + breite);
		}

		this.breite = breite;
	}
	
	
	public void show() {
		System.out.println("L�nge: " + laenge);
		System.out.println("Breite: " + breite);
	}
	
}
