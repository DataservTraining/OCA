package application;

public class Start3 {

	public static void main(String[] args) {
		Rechteck r1 = new Rechteck();
		try {
			r1.setBreite(120);
			r1.setLaenge(-10);
		} catch (IllegalArgumentException e) {
			System.out.println(e.getMessage());
			System.out.println(e.getClass().getName());
			if(e instanceof IllegalArgumentException) {
				System.out.println("IllegalArgumentException");
			}
		}
		r1.show();

	}

}
