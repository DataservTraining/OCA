package application;

public class Haus {
	
	private int anzahlStockwerke;
	private String farbe;
	private double grundflaeche;
	private boolean garage;
	
	public Haus() {
		System.out.println("Standartkonstruktor");
		farbe = "Wei�";
	}

	public Haus(int anzahlStockwerke, String farbe, double grundflaeche, boolean garage) {
//		this.anzahlStockwerke = anzahlStockwerke;
//		this.farbe = farbe;
//		this.grundflaeche = grundflaeche;
//		this.garage = garage;
		setAnzahlStockwerke(anzahlStockwerke);
		setFarbe(farbe);
		setGrundflaeche(grundflaeche);
		setGarage(garage);
	}
	
	public int getAnzahlStockwerke() {
		return anzahlStockwerke;
	}
	
	public void setAnzahlStockwerke(int anzahlStockwerke) {
		if(anzahlStockwerke < -10 || anzahlStockwerke > 150) {
			System.out.println("ung�ltiger Wert f�r die Anzahl der Stockwerke: " + anzahlStockwerke);
			return;
		}
		this.anzahlStockwerke = anzahlStockwerke;
	}

	public String getFarbe() {
		return farbe;
	}

	public void setFarbe(String farbe) {
		
		this.farbe = farbe;
	}

	public double getGrundflaeche() {
		return grundflaeche;
	}

	public void setGrundflaeche(double grundflaeche) {
		this.grundflaeche = grundflaeche;
	}

	public boolean isGarage() {
		return garage;
	}

	public void setGarage(boolean garage) {
		this.garage = garage;
	}
	
	public void show() {
		System.out.println("Anzahl Stockwerke: " + anzahlStockwerke);
		System.out.println("Farbe:             " + farbe);
		System.out.println("Grundfl�che:       " + grundflaeche);
		System.out.println("garage:            " + garage);
	}

}
