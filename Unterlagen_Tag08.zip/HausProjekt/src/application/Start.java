package application;

public class Start {

	public static void main(String[] args) {
		int x = 5;
		x = 20;

		System.out.println("Haus 1: ");
		Haus haus1 = new Haus();
		haus1.show();

//		haus1.anzahlStockwerke = 51263716;
//		System.out.println(haus1.anzahlStockwerke);
		
		haus1.setAnzahlStockwerke(4);
		haus1.setFarbe("Gelb");
		haus1.setGrundflaeche(200.45);
		haus1.setGarage(true);
		
		haus1.show();
//		System.out.println(haus1);
//		System.out.println(Integer.toHexString(haus1.hashCode()));

		System.out.println("\nHaus 2: ");
		
		Haus haus2 = new Haus(8, "Rot", 450.45, false);

		haus2.show();
		
//		haus2.setAnzahlStockwerke(8);
//		haus2.setFarbe("Rot");
//		haus2.setGrundflaeche(450.45);
//		haus2.setGarage(false);
		
		haus2.show();
		
		return;

	}

}
