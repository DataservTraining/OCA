package db;

import entities.Person;

public class MariaDbImpl implements DbInterface{

	@Override
	public void speichernPerson(Person p) {
		System.out.println("Person in MariaDB gespeichert");
		
	}

	@Override
	public void loeschenPerson(Person p) {
		System.out.println("Person aus MariaDB gel�scht");
		
	}

	@Override
	public void aendernPerson(Person p) {
		System.out.println("Person auf MariaDB ge�ndert");
		
	}

	@Override
	public Person suchePerson(int id) {
		System.out.println("Person in MariaDB gefunden");
		return new Person();
	}
}
