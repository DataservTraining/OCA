package interfacesjava8;

public class Start {

	public static void main(String[] args) {
		InterfaceATest iat = new InterfaceATest();
		iat.t1();
		iat.t2();
		A.t3();
		iat.showX();
		System.out.println("==================================");
		InterfaceDTest idt = new InterfaceDTest();
		idt.t1();
		idt.t2();
		idt.t5();
		idt.t6();
		

	}

}
