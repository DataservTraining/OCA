package application;

public class Lasttier implements Lebewesen, Transportmittel{
	
	private boolean satt;
	private double gewicht = 500;
	private String name = "Fridolin";

	@Override
	public void erhoeheGewicht(double zuladung) {
		this.gewicht += zuladung;
		satt = false;
	}

	@Override
	public void sattwerden() {
		this.satt = true;
	}

	@Override
	public String toString() {
		return "Ich hei�e " + name + ", wiege " + gewicht + " kg und bin " + (satt ? "satt" : "hungrig") + "!";
	}
	
	
	
	

}
