package application;

public class Child1 extends Parent {

	@Override
	public void test() {
		System.out.println("Child1.test()");
	}

	public void test1() {
		System.out.println("Child1.test()");
	}
	
}
