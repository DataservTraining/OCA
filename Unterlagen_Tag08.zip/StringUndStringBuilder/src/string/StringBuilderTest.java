package string;



public class StringBuilderTest {

	public static void main(String[] args) {
		StringBuilder builder1 = new StringBuilder(); // 16 Chars
		StringBuilder builder2 = new StringBuilder("Hallo Welt"); // L�nge der Zeichenkette (10) + 16 Chars
		StringBuilder builder3 = new StringBuilder(3000); // L�nge der Zeichenkette (10) + 16 Chars
		StringBuilder builder4 = new StringBuilder("start");
		System.out.println("builder1: Size: " + builder1.length() + "\tCapacity: " + builder1.capacity());
		System.out.println("builder2: Size: " + builder2.length() + "\tCapacity: " + builder2.capacity());
		System.out.println("builder3: Size: " + builder3.length() + "\tCapacity: " + builder3.capacity());
		System.out.println("builder4: Size: " + builder4.length() + "\tCapacity: " + builder4.capacity());
		
		System.out.println(builder4);
		builder4.append("middle").append("end");
		System.out.println(builder4);
		System.out.println("builder4: Size: " + builder4.length() + "\tCapacity: " + builder4.capacity());
		builder4.append(new Person());
		System.out.println(builder4);
		System.out.println("builder4: Size: " + builder4.length() + "\tCapacity: " + builder4.capacity());
//		System.out.println(builder4);
		System.out.println("builder4: Size: " + builder4.length() + "\tCapacity: " + builder4.capacity());
		Person p = null;
		builder4.append(p);
		System.out.println(builder4);
		String text = builder2.toString();
		
		System.out.println(builder2);
		System.out.println(text);
		
		
		builder4.delete(0, builder4.length());
		System.out.println("builder4: Size: " + builder4.length() + "\tCapacity: " + builder4.capacity());
		builder4.trimToSize();
		System.out.println("builder4: Size: " + builder4.length() + "\tCapacity: " + builder4.capacity());
	}
	

}

