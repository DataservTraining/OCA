
public class Exercise5 {
	public Exercise5()
	  {
		try {
	    System.out.println("10111011 ist " + BinaryStringToNumber.parseBinary("10111011"));
	    String s = "10511011";
	    System.out.println(s + " ist " + BinaryStringToNumber.parseBinary(s));
		} catch(NoBinaryException e) {
			System.out.println(e.getMessage());
			throw e;
		}
	  }
	  
	public static void main(String[] args)
	  {
		  try {
		  Exercise5 ConvertingBinary = new Exercise5();
		  } finally {
			System.out.println("finally");
		}
	  }
}
