package entities;

public abstract class MyApplication {
	private MyDocument[] docs = new MyDocument[10];
	private int index = 0;
	
	public void newDocument() {
		if(index < docs.length) {
			MyDocument doc = createDocument();
			docs[index] = doc;
			index++;
			doc.save();
		} else {
			System.out.println("es k�nnen keine weiteren Dokumente angelegt werden");
		}
		
	}

	protected abstract MyDocument createDocument();

}
