
public class Start {

	public static void main(String[] args) {
		int array[] [] = new int[2][];
		
		array[0] = new int[2];
		array[1] = new int[4];
		
		array[0][0] = 0;
		
		for(int zeile = 0; zeile < array.length; ++zeile) {
			for(int spalte = 0; spalte < array[zeile].length; ++spalte) {
				
			}
		}

		test1();
		Start st = new Start();
		st.test2();
	}
	
	static void test1() {
		test4();
	}
	
	void test2() { test3(); }
	
	void test3() {test4();}
	static void test4() {}

}


class Test{
	
private int x = 6;

	public Object testMethod(final int z) {
		final int y = 9;
//		y = 5;
//		z = 3;
		
		class MethodInnerClass{
			public String toString() {
				System.out.println(y);
				System.out.println(z);
				return y + " + " + z;
			}
		}
		MethodInnerClass mic = new MethodInnerClass();
		return mic;
	}

  private class innerTest{
	  public void show() {
		  System.out.println(x);
	  }
  }
  
  public static class InnerStaticClass{
	  
  }
}
