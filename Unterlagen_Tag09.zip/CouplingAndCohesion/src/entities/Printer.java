package entities;

public class Printer {
	
//	public void print(Person pers) {
//		System.out.println("Name: " + pers.getVorname() + " " + pers.getNachname());
//		System.out.println("Alter: " + pers.getAlter());
//		System.out.println("Stra�e: " + pers.getAdresse().getStrasse());
//		System.out.println("Ort: " + pers.getAdresse().getOrt());
//	}

	public void print(String vorname, String nachname, int alter, String strasse, String ort) {
		System.out.println("Name: " + vorname + " " + nachname);
		System.out.println("Alter: " + alter);
		System.out.println("Stra�e: " + strasse);
		System.out.println("Ort: " + ort);
	}

}
