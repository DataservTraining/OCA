package application;

import java.io.FileWriter;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Start2 {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		int x = 0, y = 0, erg = 0;
		
		while (true) {
			try (Scanner scanner = new Scanner(System.in); FileWriter fw = new FileWriter("test.txt")) {
				
				System.out.println("Bitte erste Zahl eingeben:");
				x = scanner.nextInt();
				System.out.println("Bitte zweite Zahl eingeben:");
				y = scanner.nextInt();
				erg = x / y;

				break;
			} 
			catch (ArithmeticException | InputMismatchException e) {

				if (e instanceof InputMismatchException) {
//					scanner.nextLine();
					System.out.println("Das war keine Zahl");
				} else {
					System.out.println("0 ist als Divisor nicht zul�ssig!");
				}
			}
//			catch(InputMismatchException e) {
//				scanner.nextLine();
//				System.out.println("Das war keine Zahl");
//			} 
			catch (Exception e) {

			}
		}

		System.out.println(erg);

	}

}
