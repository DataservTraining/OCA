package application;

public class Lebewesen {

	private int alter = 0;

	public Lebewesen() {
		super();
	}

	public Lebewesen(int alter) {
		super();
		this.alter = alter;
	}
	
	
	
	
}
