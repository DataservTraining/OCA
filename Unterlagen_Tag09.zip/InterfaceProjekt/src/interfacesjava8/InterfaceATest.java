package interfacesjava8;

public class InterfaceATest implements A, B{

	@Override
	public void t1() {
		System.out.println("public void t1()");
	}

	@Override
	public void t2() {	// muss zwingend �berschrieben werden, da in beiden Interfaces enthalten
		System.out.println("public void t2() in class InterfaceATest");
	}
	
	public void showX() {
		System.out.println(A.X);
		System.out.println(B.X);
		System.out.println(Y);
	}
	
	
}
