package application;

public interface Lebewesen {
	
	public void sattwerden();

}
