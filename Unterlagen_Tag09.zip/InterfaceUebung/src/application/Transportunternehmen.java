package application;

public class Transportunternehmen {
	
	public void beladen(Transportmittel tm, double gewicht) {
		tm.erhoeheGewicht(gewicht);
	}

}
