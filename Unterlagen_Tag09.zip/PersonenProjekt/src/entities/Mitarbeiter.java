package entities;

public class Mitarbeiter extends Person {
	
	private int MaNr;
	private int Abteilung;
	private Adresse adresse;
	private Mitarbeiter chef;
	
	public Mitarbeiter() {
		this("unbekannt", "unbekannt", 0, 0, 0, "unbekannt", "unbekannt");
	}

	public Mitarbeiter(int maNr, int abteilung) {
		this("unbekannt", "unbekannt", 0, maNr, abteilung, "unbekannt", "unbekannt");
		MaNr = maNr;
		Abteilung = abteilung;
	}

	public Mitarbeiter(String vorname, String nachname, int alter, int maNr, int abteilung, String strasse, String ort) {
		super(vorname, nachname, alter);
		MaNr = maNr;
		Abteilung = abteilung;
		adresse = new Adresse(strasse, ort);
	}

	public int getMaNr() {
		return MaNr;
	}

	public void setMaNr(int maNr) {
		MaNr = maNr;
	}

	public int getAbteilung() {
		return Abteilung;
	}

	public void setAbteilung(int abteilung) {
		Abteilung = abteilung;
	}

	@Override
	public String toString() {
		return "Mitarbeiter [MaNr=" + MaNr + ", Abteilung=" + Abteilung + ", Vorname=" + getVorname()
				+ ", Nachname=" + getNachname() + ", Alter=" + getAlter() + "]";
	}
	
	

	public Adresse getAdresse() {
		return adresse;
	}

	public void setAdresse(Adresse adresse) {
		this.adresse = adresse;
	}

	public void setAdresse(String strasse, String ort) {
		if(adresse == null) {
			adresse = new Adresse(strasse, ort);
		} else {
			adresse.setStrasse(strasse);
			adresse.setOrt(ort);
		}
		
	}

	@Override
	public void show() {
		System.out.println("MaNr:  " + MaNr);
		super.show();
		
		System.out.println("Abt.:  " + Abteilung);
	}
	

	
	
}
