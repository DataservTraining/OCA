
public class BinaryStringToNumber {
	public static int parseBinary(String s) throws NoBinaryException
	  {
	    int result = 0;

	    for (int i = 0; i < s.length(); i++)
	    {
	      char c = s.charAt(i);
	      if ((c != '1') && (c != '0'))
	      {
	        throw new NoBinaryException(s, i+1);
	      }
	      else
	      {
	        result *= 2;
	        if (c == '1')
	        {
	          result++;
	        }
	      }
	    }
	    return result;
	  }
}
