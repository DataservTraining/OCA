package first;

public class A {
	protected int j;

	// some codes
	public void change() {
		j = 12;
	}
}
