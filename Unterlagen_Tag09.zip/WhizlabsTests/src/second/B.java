package second;

import first.A;

class B extends A {
	int x = j;

	public static void main(String[] args) {
		A a = new A();
		a.change();
//		System.out.print(j);
	}
	
	void test() {
		System.out.println(j);
	}
}