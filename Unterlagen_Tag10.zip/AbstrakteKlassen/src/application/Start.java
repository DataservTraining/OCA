package application;

import entities.MyApplication;
import entities.MyWordApplication;

public class Start {

	public static void main(String[] args) {
		
		MyApplication wordApp = new MyWordApplication();
		wordApp.newDocument();

	}

}
