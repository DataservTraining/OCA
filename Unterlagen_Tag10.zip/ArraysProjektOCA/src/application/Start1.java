package application;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class Start1 {

	public static void main(String[] args) {
		int x;
		int[] array1 = {23, 45, 56, 78}; // wird automatisch mit der 
										 // entsprechenden Gr��e und den Werten initialisiert 
//		int[] array1 = new int[] {23, 45, 56, 78}; 
		int array2[] = new int[10];  // wird automatisch mit dem jeweiligen Basiswert initialisiert 
		int[] f1, f2; // 2 Referenzvariablen auf int[]
		int f3[], f4; // 1  Referenzvariablen auf int[] und eine Variable vom Typ int

		String[] bugs = {"cricket", "beetle", "ladybug"}; 
		String[] bugs2 = {"cricket", "beetle", "ladybug"}; 
		Person[] persons = {new Person(), new Person(), new Person()}; 
		String[] alias = bugs;
		System.out.println(bugs2.equals(bugs));
		System.out.println(alias.equals(bugs));
		System.out.println(bugs.toString());
		
		String[] strings = {"stringValues"};
		Object[] objects = strings;
		strings = (String[]) strings;
		//objects[0] = new StringBuilder();
		Object[] builders = new Object[1];
		builders[0] = new StringBuilder();
		System.out.println(bugs.length);
		System.out.println(array2.length);
		
//		array2[10] = 6;
		for(int i = 0; i < array2.length; ++i) {
			array2[i] = i + 5;
//			System.out.println(array2[i+5]);
		}
		System.out.println("========================================");
		Integer[] numbers = {6, 2, 9, 6, 4, 5,9, 1};
		for(int i : numbers) System.out.print(i + ", ");
		System.out.println();
//		Arrays.sort(numbers, new Comparator<Integer>() {
//
//			@Override
//			public int compare(Integer oo1, Integer oo2) {
//				int o1 = oo1;
//				int o2 = oo2;
//				// o1 in Sortierung vor o2: Wert < 0 
//				// o2 in Sortierung vor o1: Wert > 0 
//				// o2 in Sortierung an gleicher Stelle wie o1: Wert == 0
////				if(o1 % 2 == 0 && o2 % 2== 0) return 0;
//				if(o1 % 2 != 0 && o2 % 2== 0) return -1;
//				if(o1 % 2 == 0 && o2 % 2 != 0) return 1;
//				return 0;
//			}
//		});
		
		Arrays.sort(numbers);
		
		

		for(int i : numbers) System.out.print(i + ", ");
		
		System.out.println("G��e von numbers: " + numbers.length);
//		Integer[] temp = new Integer[numbers.length * 2];
//		for(int i = 0; i < numbers.length; ++i) {
//			temp[i] = numbers[i];
//		}
//		numbers = temp;

		numbers = Arrays.copyOf(numbers, numbers.length * 2);
		for(int i = 0; i < numbers.length; ++i) {
		numbers[i] = numbers[i] == null ? 0 : numbers[i];
	}
		
		System.out.println("G��e von numbers: " + numbers.length);
		
		System.out.println();
		System.out.println("BinarySearch 8: " + Arrays.binarySearch(numbers, 10));
		String[] namen = {"java", "jaVa", "Java"};
		for(String i : namen) System.out.print(i + ", ");
		System.out.println();
		Arrays.sort(namen);
		for(String i : namen) System.out.print(i + ", ");
		System.out.println();
		
		int ergebnis = add(2, 452, 5, 7, 3, 9, "lsdkflksd");
	}
	
	public static int add(int wert, Object... args) {
		int summe = wert;
		
		for( int index = 0; index < args.length; ++index) {
			if(args[index] instanceof Integer)
			summe += (Integer)args[index];
		}
		
//		for(Object w : args) {
//			if(w instanceof Integer)
//				summe += (Integer)w;
//		}
		return summe;
	}

}
