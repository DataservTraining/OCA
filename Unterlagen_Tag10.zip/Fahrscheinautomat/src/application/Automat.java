package application;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Automat {

	public static void main(String[] args) {
		List<Integer> stueckelung = Arrays.asList(200, 100, 50, 20, 10);
		List<Integer> gueltigenWerte = Arrays.asList(5000, 2000, 1000, 500, 200, 100, 50, 20, 10);
		int preis;
		Scanner scanner = new Scanner(System.in);
		String tarif;
		
		while(true) {
			preis = 0;
			while(preis == 0) {
				System.out.println("Tarif A        2,80 �");
				System.out.println("Tarif B        3,60 �");
				System.out.println("Tarif C        7,30 �");
				System.out.println("Bitte w�hlen Sie einen Tarif aus");
				tarif = scanner.nextLine().toLowerCase().trim();
				if(tarif.isEmpty()) {
					continue;
				}
				switch(tarif.charAt(0)) {
				case 'a': preis = 280;
							break;
				case 'b': preis = 360;
				break;
				case 'c': preis = 730;
				break;
				case 'q': System.exit(0);
				default:
					System.out.println("ung�ltiger Tarif");			
				}
			}
			
			do {
				System.out.printf("Bitte noch %.2f � einwerfen\n", preis/100.0);
				int einwurf = (int)(scanner.nextDouble() * 100);
				if(gueltigenWerte.contains(einwurf)) {
					preis -= einwurf;
				} else {
					System.out.println("Bitte kein Falschgeld!!!");
				}
			} while(preis > 0);
			scanner.nextLine();
			
			if(preis < 0) {
				preis *= -1;
				for(int wert : stueckelung) {
					int anzahl = preis / wert;
					if(anzahl > 0) {
						System.out.printf("%d mal %.2f �\n", anzahl, wert/100.0);
					}
					preis %= wert;
				}
			}
			
			System.out.println("Bitte Fahrschein entnehmen");
		}

	}

}
