package application;

public class Start2 {

	public static void main(String[] args) {
		int[] stueckelung = { 200, 100, 50, 20, 10, 5, 2, 1 };
		int nachkommastellen = 2;
		double divisor = 100.0;
		String waehrungString = "�";
		String format = "%d mal %." + nachkommastellen + "f %s\n";
		int betrag = 9720;
		int anzahl = 0;
		int positiv = Math.abs(betrag);

		for (int index = 0; index < stueckelung.length; ++index) {
			if ((anzahl = betrag / stueckelung[index]) > 0) {
				System.out.printf(format, anzahl, stueckelung[index] / divisor, waehrungString);
			}
			betrag %= stueckelung[index];
		}
	}
}
