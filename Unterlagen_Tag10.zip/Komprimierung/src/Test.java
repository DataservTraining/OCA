import java.util.ArrayList;
import java.util.List;

public class Test {

	public static void main(String[] args) {
		int anzahl = 0;
		int index = 0;
		int i = 0;
//		char[] bildDaten = {'Q','Q','Q','Q',
//				            'R','R','R','R','R','R',
//				            'T','T','T','T','T','T','T','T','T','T',
//				            'L','L','L','L','L','L','L','L','L','L','L',
//				            'M',
//				            'N','N','N',
//				            'V','V','V','V','V','V','V','V','V','V','V',
//				            'A','A','A','A','A','A','A','A','A','A','A','A','A'};

		char[] bildDaten = {'Q','Q','Q', 'Q',
				'R','R','R','R','R',
//				'T','T','T','T','T','T','T','T','T','T',
//				'L','L','L','L','L','L','L','L','L','L','L',
				'M',
				'N','N', 'V'
//				'V','V','V','V','V','V','V','V','V','V','V',
//				'A','A','A','A','A','A','A','A','A','A','A','A','A'
		};

		List<String> komprimierteDaten = new ArrayList<>();
		while(index < bildDaten.length) {
			anzahl = 0;
			i = index;
			while(i < bildDaten.length && bildDaten[i] == bildDaten[index]) {
				i = i + 1;
				anzahl = anzahl + 1;
			}
			if(anzahl > 3) {
				komprimierteDaten.add("�");
				komprimierteDaten.add(Integer.toString(anzahl));
				komprimierteDaten.add(Character.toString(bildDaten[index]));
				index = index + anzahl;
			} else {
				i = 0;
				while(i < anzahl) {
					komprimierteDaten.add(Character.toString(bildDaten[index]));
					i =  i + 1;
				}
				index = index + anzahl;
			}
		}
			System.out.print("[");
			for(char ch : bildDaten) System.out.print(ch);
			System.out.println("]");
			System.out.println(komprimierteDaten);
	}

}
