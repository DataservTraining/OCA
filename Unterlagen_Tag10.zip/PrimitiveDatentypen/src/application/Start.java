package application;

public class Start {
	private static int d;
	public static void main(String[] args) {
		int x = 3, y = 8;
		int w, z;
//		System.out.println(w);
		System.out.println(d);
		
		
		w = z = 928_374_984;
		x = 0b1_00101010;
		x = 0271;
		System.out.println(x);
		
		float f = 324.56F;
		double d = 2344.344D;
		System.out.println(Character.BYTES);
		System.out.println(Character.MAX_VALUE);
		System.out.println(Character.MIN_VALUE);
		System.out.println(Character.SIZE);

	}

}
