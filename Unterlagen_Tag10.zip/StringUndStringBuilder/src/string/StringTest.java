package string;

public class StringTest {

	public static void main(String[] args) {
		String text = "Hallo";
		String hallo = "Hallo";
		String hallo2 = new String("Hallo");
		String hallo3 = new String("Hallo");
		
		String text2 = text + " Welt" + "dsfklj";
//		text += " Welt"; 
		
		if(text == hallo) {
			System.out.println("text ist gleich hallo");
		}
		
		if(hallo2 == hallo3) {
			System.out.println("hallo2 ist gleich hallo3");
		} else {
			System.out.println("hallo2 ist nicht gleich hallo3");
		}
		
		if(hallo2.equals(hallo3)) {
			System.out.println("hallo2.equals(hallo3) ist true");
		} else {
			System.out.println("hallo2.equals(hallo3) ist false");
		}
		// charAt()
		System.out.println("L�nge von hallo: " + hallo.length());
		System.out.println("2. Zeichen von hallo: " + hallo.charAt(1));
		System.out.println("2. Zeichen von hallo: " + hallo.charAt(4));
//		System.out.println("2. Zeichen von hallo: " + hallo.charAt(5)); // liefert StringIndexOutOfBoundsException
		
		// indexOf()
		String string = "animals";
		System.out.println(string.indexOf('a'));
		System.out.println(string.indexOf("al"));
		System.out.println(string.indexOf('y', -1));
		System.out.println(string.indexOf("al", 8));
		System.out.println("==========================");
		
		for(int fromindex = 0; fromindex < string.length(); ++fromindex) {
			System.out.println(string.indexOf('a', fromindex));
		}
		
		// substring()
		
		System.out.println(string.substring(2));
		System.out.println(string.substring(2, 4));  // fromindex incl. endindex excl.
		System.out.println(string.substring(2, 7));  // fromindex incl. endindex excl.
//		System.out.println("endindex > string.length(): " + string.substring(2, 8));  // fromindex incl. endindex excl. 
		                                             // au�erhalb der L�nge -> StringIndexOutOfBoundsException
		System.out.println("fromindex == endindex: " + string.substring(2, 2));  // fromindex incl. endindex excl.
//		System.out.println("fromindex > endindex: " + string.substring(2, 1));  // StringIndexOutOfBoundsException
//		System.out.println("fromindex < 0: " + string.substring(-1, 1));  // StringIndexOutOfBoundsException
//		System.out.println("fromindex < 0: " + string.substring(-1));  // StringIndexOutOfBoundsException
		
		String substring = string.substring(3);
		System.out.println(substring);
		System.out.println("==========================\ntoLowerCase(), toUpperCase()");
		// toLowerCase(), toUpperCase()
		string = "Animals";
		System.out.println(string);
		String toLower = string.toLowerCase();
		System.out.println(toLower);
		String toUpper = string.toUpperCase();
		System.out.println(toUpper);
		// Animals != animals
		String kleinBuchstaben = "abc";
		String grossBuchstaben = "ABC";
		if (kleinBuchstaben.equalsIgnoreCase(grossBuchstaben)) {
			System.out.println(kleinBuchstaben + " == " + grossBuchstaben);
		}
		System.out.println("==========================\nstartsWith(), endsWith()");
		// startsWith(), endsWith()
		string = "animals";
		System.out.println(string.startsWith("an"));
		System.out.println(string.startsWith("an", 2));
		System.out.println(string.endsWith("als"));
		
		System.out.println("==========================\ncontains()");
		// contains()
		System.out.println(string.contains("im"));
		
		System.out.println("==========================\nreplace()");
		// replace()
		String replacedChar = string.replace('a', 'u');
		System.out.println(string);
		System.out.println(replacedChar);
		String replacedString = replacedChar.replace("un", "on");
		System.out.println(replacedChar.replace("un", "on"));
		System.out.println(replacedChar);
		System.out.println(replacedString);
		
		System.out.println("==========================\ntrim()");
		// trim()
		
		string = "    animals     ";
		System.out.println(string);
		System.out.println(string.trim());
		
		string = "    An Im AlS    ";
		
		String geaendert = string.trim().toLowerCase().substring(2, 5).replace('a', 'u').
							replace(' ', '\0').toUpperCase();
		System.out.println(geaendert);
		string = " im".replace(" ", "");
		text = String.format("Das Ergebnis von %d + %d = %d\n", 3, 6, (3+6));
		System.out.println(text);
		System.out.printf("Heute ist der %02d.%02d.%02d", 28, 1, 2022);
	
		
	}

}
