import java.time.LocalDate;
import java.time.MonthDay;
import java.time.Year;

public class Test1 {

	public static void main(String args[]) {
//		StringBuilder sb = new StringBuilder("Whizlab");
//		char[] ch = new char[4];
//		sb.getChars(1, 5, ch, 1);
//		for (char c : ch)
//			System.out.print(c);
//		
	     Year y = Year.of(2015); 
	     LocalDate date = y.atMonthDay(MonthDay.of(4,31)); 
	     System.out.println(date); 
	}

}
