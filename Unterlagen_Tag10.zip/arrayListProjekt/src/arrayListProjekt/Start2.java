package arrayListProjekt;

import java.util.ArrayList;
import java.util.List;

public class Start2 {

	public static void main(String[] args) {
		List<String> strings = new ArrayList<>();
		strings.add("A");
		strings.add("B");
		strings.add("C");
		
		String[] arr = new String[6];
		for(int index = 0, ch=80; index < arr.length; ++index, --ch) {
			arr[index] = new String(Character.toString(ch)); 
		}
		
		for(String s : arr) System.out.print(s);
		System.out.println();
		arr = new String[strings.size()];
		arr = strings.toArray(arr);
		
		for(String s : arr) {
			System.out.print(s);
		}
		System.out.println();
	}

}
