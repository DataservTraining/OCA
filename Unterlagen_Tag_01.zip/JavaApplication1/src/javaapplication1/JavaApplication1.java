/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication1;
import static java.lang.Math.*;
//import static java.lang.Math.PI;
/**
 *
 * @author Guido
 */
class JavaApplication1 {
    private static int x = 4;
    
    private String name;
    
    private class myClass{
    
    }
    
    public static int getX(){
        return x;
    }
    
    public void setName(String n){
        name = n;
    }
    public static void main(String[] args) {
        class myLocalClass{
            
        }
        
        double square = sqrt(4);
        System.out.println(square);
        System.out.println(PI);
        
        int _allowed = 1236;
        for(int x = 5; 
            x < 10; 
            x++) {   
        x++;
        }
        
        for(int x = 5; 
                x < 10; 
                x++);
            x++;
        int a = 5, b = 8, s=4;
            int ergebnis = a++ * b - ++a / a * s;
            System.out.println(ergebnis);
            
        System.out.println(x--);
        
        if(5 == 5) System.out.println("Hallo");
            
        System.out.println("Welt");
        
        int x = 0;
        int y = 0;
        do{
            y = x++;
            System.out.println(y);
        } while(y < 5);
        
        
        boolean run = true;
        while(run){
            System.out.println(y--);
            run = y > 0;
        }
        
        int zaehler = 0;
        
        for(;;){
            System.out.println("Zähler in for()" + zaehler);
            zaehler++;
            if(zaehler == 3) {
                break;
            }
            
        }
                
        
        
        
//        else
//            System.out.println("dskjfhfhsjkaf");
    }
    
}
