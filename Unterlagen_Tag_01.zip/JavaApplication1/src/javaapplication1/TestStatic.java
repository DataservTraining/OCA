
package javaapplication1;

/**
 *
 * @author Guido
 */
public class TestStatic {
    public static int a;
    
    static{
        System.out.println("sjkdfhskljdfsdj");
    }
    
    public static void main(String[] args) {
        Test t;
    }
    
}


class Test{
    
}