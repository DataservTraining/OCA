package com.oracle.utilities;

public class A {
    private int w = 10;
    int x = 20;
    protected int y = 30;
    public int z = 40;
    
    public void test(){
        System.out.println("w: " + w);
        System.out.println("x: " + x);
        System.out.println("y: " + y);
        System.out.println("z: " + z);
    }
}
