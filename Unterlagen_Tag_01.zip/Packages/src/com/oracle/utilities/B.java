package com.oracle.utilities;

public class B {
    
    public void test(){
        A a = new A();
        //System.out.println("w: " + a.w);
        System.out.println("x: " + a.x);
        System.out.println("y: " + a.y);
        System.out.println("z: " + a.z);
    }
    
}
