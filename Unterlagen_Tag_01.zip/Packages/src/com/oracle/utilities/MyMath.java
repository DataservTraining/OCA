package com.oracle.utilities;

public class MyMath {
    
}
