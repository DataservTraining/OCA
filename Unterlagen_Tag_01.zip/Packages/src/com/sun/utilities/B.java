package com.sun.utilities;

public class B extends com.oracle.utilities.A{
    public void test(){
        com.oracle.utilities.A a = new com.oracle.utilities.A();
        //System.out.println("w: " + a.w);
        //System.out.println("x: " + a.x);
        System.out.println("y: " + y);
        System.out.println("y: " + a.y);
        System.out.println("z: " + a.z);
    }
}
