package com.sun.utilities;

public class MyMath {
    
}
