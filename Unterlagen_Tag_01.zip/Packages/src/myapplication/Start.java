package myapplication;
import com.oracle.utilities.MyMath;
import com.oracle.utilities.A;
import com.sun.utilities.B;

public class Start {

    public static void main(String[] args) {
        MyMath math1 = new MyMath();
        A a =  new A();
        System.out.println(a.z);
        B b = new B();
    }
    
}
