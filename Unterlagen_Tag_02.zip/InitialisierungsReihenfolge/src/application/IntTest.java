package application;

import java.util.ArrayList;

class MyInteger{
	private int value;

	public MyInteger(int wert) {
		super();
		this.value = wert;
	}
	
	
	public int getValue() {
		return value;
	}
	
}

public class IntTest {

	public static void main(String[] args) {
		byte b;   // Byte
		short s;   //Short
		int x = 10;   // Integer
		long l;      //Long
		
		float f;     //Float
		double d;    // Double
		
		char ch;    //Character
		boolean ok; // Boolean
		
		Integer integer = Integer.valueOf(12);
		
		ArrayList<Integer> liste = new ArrayList<Integer>();

	}

}
