package application;

public class Person extends Lebewesen {
	private String name ="direkt";
	
	{
		name = "Initialisierung";
	}

	public Person() {
		this(10, "Name aus Standardkonstruktor");
		//name = "Standardkonstruktor";
	}

	public Person(String name) {
		this(10, name);
	}
	
	public Person(int alter, String name) {
		super(alter);
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	{
		System.out.println("zweiter Initialisierungsblock");
	}
	
	

}
