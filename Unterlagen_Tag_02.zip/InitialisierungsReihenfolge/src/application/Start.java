package application;

public class Start {

	public static void main(String[] args) {
		Person person1 = new Person();
		Person person2 = new Person("Franz");
		Person person3 = new Person(30, "Jupp");

		person1.setName("Willi");
		System.out.println(person1.getName());
		person2.setName("Fritz");
		System.out.println(person2.getName());
	}

}
