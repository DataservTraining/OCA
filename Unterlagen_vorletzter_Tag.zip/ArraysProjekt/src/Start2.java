
public class Start2 {

	public static void main(String[] args) {
		int[][] ints = new int[3][1];
		
		for(int[] zeile : ints) {
			for(int spalte : zeile) {
				System.out.print(spalte + ", ");
			}
			System.out.println();
		}
		
		ints[1] = new int[10];
		System.out.println();
		for(int[] zeile : ints) {
			for(int spalte : zeile) {
				System.out.print(spalte + ", ");
			}
			System.out.println();
		}
	}
	
}
