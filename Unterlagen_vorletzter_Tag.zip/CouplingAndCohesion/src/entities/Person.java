package entities;

public class Person {

	private Adresse adresse;
	private String vorname;
	private String nachname;
	private int alter;
	
	public Person(String strasse, String ort, String vorname, String nachname, int alter) {
		super();
		if(adresse == null) {
			this.adresse = new Adresse(strasse, ort);
		} else {
			adresse.setStrasse(strasse);
			adresse.setOrt(ort);
		}
		this.vorname = vorname;
		this.nachname = nachname;
		this.alter = alter;
	}

	public Adresse getAdresse() {
		return adresse;
	}

	public void setStrasse(String strasse) {
		this.adresse.setStrasse(strasse);
	}
	
	public void setOrt(String ort) {
		this.adresse.setOrt(ort);
	}

	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public String getNachname() {
		return nachname;
	}

	public void setNachname(String nachname) {
		this.nachname = nachname;
	}

	public int getAlter() {
		return alter;
	}

	public void setAlter(int alter) {
		this.alter = alter;
	}
	
	public double berechneFlaeche (double laenge, double breite) {
		return laenge * breite;
	}
	
}
