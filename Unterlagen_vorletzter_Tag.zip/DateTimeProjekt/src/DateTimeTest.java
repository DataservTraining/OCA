//import java.time.LocalDate;
//import java.time.LocalDateTime;
//import java.time.LocalTime;

import java.time.*;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalUnit;

public class DateTimeTest {

	public static void main(String[] args) {
		LocalDate localDate = LocalDate.now();
		LocalTime localTime = LocalTime.now();
		LocalDateTime localDateTime = LocalDateTime.now();
		System.out.println(localDate);
		System.out.println(localTime);
		System.out.println(localDateTime);
		LocalDate date1 = LocalDate.of(2020, 2, 12);
		LocalDate date2 = LocalDate.of(2020, Month.APRIL, 12);
		
		LocalTime time1 = LocalTime.of(13, 59);
		LocalTime time2 = LocalTime.of(13, 59, 56);
		LocalTime time3 = LocalTime.of(12, 59, 56, 8976);
		System.out.println(time1);
		System.out.println(time2);
		System.out.println(time3);
		
		LocalDateTime dateTime1 = LocalDateTime.of(2019, Month.FEBRUARY, 28, 10, 45);
		System.out.println(dateTime1);
		System.out.println("=================================");
		System.out.println("date1: " + date1);
		LocalDate date1Plus10 = date1.plusDays(20);
		System.out.println("date1: " + date1Plus10);
		System.out.println(date1Plus10.isLeapYear());
		System.out.println("Date1Plus10Plus2Years: " + date1Plus10.plusYears(2));
		System.out.println("date1Plus10: " + date1Plus10);
		System.out.println();
		System.out.println("time1: " + time1);
		System.out.println("time1: " + time1.plusHours(2));
	}

}
