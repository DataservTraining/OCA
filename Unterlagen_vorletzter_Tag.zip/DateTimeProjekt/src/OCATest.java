import java.time.LocalDate;
import java.time.LocalTime;
import java.util.function.BiFunction;

public class OCATest {

	public static void main(String[] args) {
		System.out.println(new String("Hallo Welt"));
		System.out.println(LocalTime.now());
		LocalDate date = LocalDate.now();
		System.out.println(date.plusWeeks(1));
		
		Thread thread = new Thread(new Runnable() {

			@Override
			public void run() {
				System.out.println("run");
			}
			
		});
		
		Runnable runnable = () -> {System.out.println("run");};
		Thread thread2 = new Thread(runnable);
		Thread thread3 = new Thread(() -> System.out.println("run"));
		BiFunction<Integer, Integer, Integer> max = (m, n) -> {return m > n ? m : n;};  
		
	}

}
