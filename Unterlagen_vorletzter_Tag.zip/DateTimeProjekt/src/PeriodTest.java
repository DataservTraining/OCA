import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Locale;

public class PeriodTest {

	
	public static void main(String[] args) {
		Period wrong = Period.of(1, 2, 20);
		System.out.println(wrong);
		wrong = Period.ofYears(1).ofMonths(3);
		System.out.println(wrong);
		wrong = Period.ofDays(20).withMonths(3).withYears(5);
		System.out.println(wrong);
		System.out.println(wrong);
		
		LocalDate date = LocalDate.now();
		System.out.println(date.getDayOfMonth());
		System.out.println(date.getMonth());
		System.out.println(date.getDayOfYear());
		System.out.println(date.getYear());
		System.out.println(date.getDayOfWeek());
		
		date = LocalDate.of(2020, Month.JANUARY, 20);
		LocalTime time = LocalTime.of(13, 55, 34);
		LocalDateTime dateTime = LocalDateTime.of(date, time);
		
		System.out.println(date.format(DateTimeFormatter.ISO_LOCAL_DATE));
		System.out.println(dateTime.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
		System.out.println(date.format(DateTimeFormatter.BASIC_ISO_DATE));
		System.out.println(time.format(DateTimeFormatter.ISO_LOCAL_TIME));
		
		DateTimeFormatter shortDateTime = DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT);
		DateTimeFormatter mediumDateTime = DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM);
		
		System.out.println(shortDateTime.format(dateTime));
		System.out.println(mediumDateTime.format(date));
//		System.out.println(shortDateTime.format(time));
		
		System.out.println(dateTime.format(shortDateTime));
		System.out.println(date.format(shortDateTime));
//		System.out.println(time.format(shortDateTime));
		
		DateTimeFormatter ofPattern = DateTimeFormatter.ofPattern("dd. MMMM yyyy HH:mm:ss,SS", Locale.ITALY);
		System.out.println(dateTime.format(ofPattern));
		
		DateTimeFormatter ofPatternEinlesen = DateTimeFormatter.ofPattern("dd. MMMM yyyy HH:mm");
		
		LocalDateTime eingelesen = LocalDateTime.parse("03. Februar 2022 14:00", ofPatternEinlesen);
//		LocalDateTime eingelesen = LocalDateTime.parse("03-02-2022 14:00");
		
		System.out.println(eingelesen);

	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return super.equals(obj);
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}

	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		super.finalize();
	}

	
}
