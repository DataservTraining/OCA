package application;

public class FalscheSeitenLaengeException extends IllegalArgumentException{
	private String method;
	private int row;
	private int errorCode;
	
	public FalscheSeitenLaengeException(String message, String method, int row, int errorCode) {
		super(message + " in Methode " + method + " in Zeile " + row + "\nFehlercode: " + errorCode);
		this.method = method;
		this.row = row;
		this.errorCode = errorCode;
	}

	public String getMethod() {
		return method;
	}

	public int getRow() {
		return row;
	}

	public int getErrorCode() {
		return errorCode;
	}
	
	
	
	
}
