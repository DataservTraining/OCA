package application;

import java.io.FileNotFoundException;
import java.sql.SQLException;

public class TestExceptionExtended extends TestException{

	@Override
	public void test() throws FileNotFoundException  {
		int y = 10;
		if(y == 10) {
			throw new FileNotFoundException("aus TestExceptionExtended.test()");
		} else {
			throw new RuntimeException("aus TestExceptionExtended.test()");
		}
		
	}
	
}
