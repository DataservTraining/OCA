package application;

public enum Gender {
MALE, FEMALE
}
