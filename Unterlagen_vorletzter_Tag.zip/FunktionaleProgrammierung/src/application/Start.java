package application;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Start {

	public static void main(String[] args) {
		Predicate<Person> isAdult = person -> person.isAdult();

		List<Person> personen = DemoData.createDemoData();
		Stream<Person> adults = personen.stream().filter(isAdult).filter(p -> p.getCity().equals("Berlin"));
		adults.forEach(System.out::println);

		Stream<Integer> alter = personen.stream().filter(isAdult).map(Person::getAge);
		alter.forEach(System.out::println);

		System.out.println("\n==============================\n");

		final List<String> names = Arrays.asList("Stefan", "Ralph", "Andi", "Mike", "Florian", "Michael", "Sebastian");

		final String joined = names.stream().sorted().filter(str -> str.contains("a"))
				.collect(Collectors.joining(", "));

		Map<Integer, List<String>> grouped = names.stream().collect(Collectors.groupingBy(String::length));

		Map<Integer, Long> counting = names.stream()
				.collect(Collectors.groupingBy(String::length, Collectors.counting()));

		Map<Boolean, List<String>> partitions = names.stream().filter(str -> str.contains("i"))
				.collect(Collectors.partitioningBy(str -> str.length() > 4));

		System.out.println("joined: " + joined);
		System.out.println("grouped: " + grouped);
		System.out.println("counting: " + counting);
		System.out.println("partitions: " + partitions);

		float x = 1.0f;
		for (int i = 0; i < 10; ++i) {
			x = x - 0.1f;
			System.out.printf("%.18f\n", x);
		}

		x = (int) (x * 100000) / 100000.0f;
		System.out.printf("%.18f\n", x);
		System.out.println(x == 0.0);

		L1: for (int i = 5, 
				     j = 0; 
				i > 0; 
				i--) {
			L2: for (; 
					j < 5; 
					j++) {
				System.out.print(i + "" + j + " ");
				if(j==0) continue L1;
			}
		}
		
		
		A a = new A(); 
		B b = new B();
		A aa = new A();
		
		A aAusMethod = a.method();
//		B bAusMethod = b.method();
		aa = b.method();
		
		Object o = aa.supply();
		aa = new C();
		o = aa.supply();
	}

}

class A{
	A method(){ return new A();}
	Object supply() throws Exception {return null;}
}

class B extends A{
	C method(){ return new C();}
}

class C extends A{
	
	public Object supply() throws IOException { return null;}       
	
}
