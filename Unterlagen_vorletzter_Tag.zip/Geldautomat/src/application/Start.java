package application;

class Waehrung{
	private int[] stueckelung;
	private String waehrung;
	private double divisor;
	private int nachkommastellen;
	
	public Waehrung(int[] stueckelung, String waehrung, double divisor, int nachkommastellen) {
		super();
		this.stueckelung = stueckelung;
		this.waehrung = waehrung;
		this.divisor = divisor;
		this.nachkommastellen = nachkommastellen;
	}
	public int[] getStueckelung() {
		return stueckelung;
	}
	public String getWaehrung() {
		return waehrung;
	}
	public double getDivisor() {
		return divisor;
	}
	public int getNachkommastellen() {
		return nachkommastellen;
	}
	
	
}

public class Start {
	public static void main(String[] args) {
		Waehrung waehrung = new Waehrung(new int[]{200, 100, 50, 20, 10, 5, 2, 1},
										 "�", 100.0, 2);
		int[] stueckelung = waehrung.getStueckelung();	
		String format = "%d mal %."+ waehrung.getNachkommastellen() + "f %s\n";
		int betrag = 436;
		int anzahl = 0;
		
		for(int index = 0; index < stueckelung.length; ++index) {
			if((anzahl = betrag / stueckelung[index]) > 0) {
				System.out.printf(format, anzahl, stueckelung[index]/waehrung.getDivisor(), 
						           waehrung.getWaehrung());
			}
			betrag %= stueckelung[index];
		}
	}
}
