
public class Cat extends Animal{

	public Cat() {
		super("Cat", true, true);
		
	}

}
