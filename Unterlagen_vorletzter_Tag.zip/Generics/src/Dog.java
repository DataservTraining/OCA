
public class Dog extends Animal{

	public Dog() {
		super("Dog", true, true);
	
	}

}
