import java.util.Arrays;

public class MyArrayList<T> {
	private T[] data;
	private int index;
	
	@SuppressWarnings("unchecked")
	public MyArrayList() {
		data = (T[])new Object[10];
		index = 0;
	}
	
	public void add(T element) {
		if(index == data.length) {
			resize();
		}
		data[index++] = element;
	}

	private void resize() {
		data = Arrays.copyOf(data, data.length * 2);
	}
	
	public T get(int index) {
		if(index < 0 || index > this.index - 1) {
			throw new IllegalArgumentException("Index falsch");
		}
		return data[index];
	}
}
