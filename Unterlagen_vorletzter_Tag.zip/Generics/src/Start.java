import java.util.ArrayList;
import java.util.List;

public class Start {

	public static void main(String[] args) {
		MyArrayList<Animal> strings = new MyArrayList<>();
		List<Animal> animals = new ArrayList<>();
		List<Cat> cats = new ArrayList<>();
		List<Dog> dogs = new ArrayList<>();
		Dog dog1 = new Dog();
		Dog dog2 = new Dog();
		Dog dog3 = new Dog();
		Dog dog4 = new Dog();
		
		Cat cat1 = new Cat();
		Cat cat2 = new Cat();
		Cat cat3 = new Cat();
		
		animals.add(cat3);
		animals.add(cat2);
		animals.add(dog1);
		animals.add(dog3);
		animals.add(cat3);
		animals.add(dog4);
		
		dogs.add(dog1);
		dogs.add(dog2);
		dogs.add(dog3);
		dogs.add(dog4);
		dogs.add(new Dog());
//		dogs.add(new Cat());
		animals.add(new Cat());
		
		cats.add(cat3);
		cats.add(cat1);
		cats.add(cat2);
		
		impfenLassen(dogs);
	}
	
	public static void impfenLassen(List<? extends Animal> animals) {
//		animals.add(new Cat());
		for(Animal a : animals) {
			a.impfen();
		}
	}

}
