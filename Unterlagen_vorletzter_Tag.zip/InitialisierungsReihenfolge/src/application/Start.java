package application;

public class Start {

	public static void main(String[] args) throws InterruptedException {

		System.out.println("Anzahl Personenobjekte: " + Person.getAnzahl());
		Person person1 = new Person();
		System.out.println("Anzahl Personenobjekte: " + Person.getAnzahl());
		Person person2 = new Person("Franz");
		System.out.println("Anzahl Personenobjekte: " + Person.getAnzahl());
		Person person3 = new Person(30, "Jupp");
		System.out.println("Anzahl Personenobjekte: " + Person.getAnzahl());
		
		System.out.println("\n===================================\n");

		person1.setName("Willi");
		System.out.println(person1.getName());
		
		person1 = null;  // danach Objekt aus Zeile 8 nicht mehr erreichbar
		System.gc();
		
		Thread.sleep(15);
		
		System.out.println("Anzahl Personenobjekte nach l�schen des Objektes aus Zeile 8: " + Person.getAnzahl());
		
		// Alternative 1:
		person1 = person2;  // danach Objekt aus Zeile 8 nicht mehr erreichbar
		
		// Alternative 2:
		person1 = new Person(); // danach Objekt aus Zeile 8 nicht mehr erreichbar
		
		person2.setName("Fritz");
		System.out.println(person2.getName());
		
		
		
	}

}
