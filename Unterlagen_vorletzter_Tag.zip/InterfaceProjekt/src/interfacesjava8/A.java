package interfacesjava8;

public abstract interface A {
	public static final int X = 8;   // bis Java 7 einschlie�lich
	public abstract void t1();       // bis Java 7 einschlie�lich
	
	public default void t2() {       // seit Java 8
		System.out.println("Interface A.t2()");
		t4();
	}
	
	public static void t3() {        // seit Java 8
		System.out.println("public static void t3()");
	}
	
	private void t4() {              // ab Java 9
		System.out.println("private void t4()");
	}
}

interface B{
	public static final int X = 9;   // bis Java 7 einschlie�lich
	public static final int Y = 19;   // bis Java 7 einschlie�lich
	
	public abstract void t1();       // bis Java 7 einschlie�lich
	
	public default void t2() {       // seit Java 8
		System.out.println("Interface B.t2()");
	}
}

interface C {
	public abstract void t5();
}

interface D extends A, B, C{
	public abstract void t6();
	public default void t2() {       // seit Java 8. Interface D muss die geerbten Methoden t2 aus Interface A und aus 
			                         // Interface B �berschreiben
		System.out.println("Interface D.t2()");
	}
}
