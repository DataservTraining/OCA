
public class CheckIfHopper implements CheckTrait<Animal>{

	@Override
	public boolean test(Animal a) {
		return a.canHop();
	}

}
