
@FunctionalInterface
public interface CheckTrait<T> {
	boolean test(T a);
}
