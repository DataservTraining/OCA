import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

class VornamenSortierung implements Comparator<Person>{

	@Override
	public int compare(Person o1, Person o2) {
		return o1.getName().compareTo(o2.getName());
	}
	
}

@FunctionalInterface
interface MyComparator<T>{
	int mycomp(T o1, T o2);
	default void test() {
		
	}
	
	static void test2() {
		
	}
}


public class CompareToTest {

	public static void main(String[] args) {
		Comparator<Person> altersSortierung1 = (Person p1, Person p2) -> {return p1.getAge() - p2.getAge();};
		MyComparator<Person> altersSortierung2 = (Person p1, Person p2) -> {return p1.getAge() - p2.getAge();};
		
		
		Set<String> strings = new TreeSet<>();
		
		strings.add("Willi");
		strings.add("Maria");
		strings.add("Werner");
		strings.add("Guido");
		strings.add("Alfons");
		
		System.out.println(strings);
		
//		Set<Person> personen = new TreeSet<>(new Comparator<Person>() {
//
//			@Override
//			public int compare(Person o1, Person o2) {
//				return o1.getAlter() - o2.getAlter();
//			}
//			
//		});
		
		
//		Set<Person> personen = new TreeSet<>(altersSortierung1);
//		personen.add(new Person("Willi", "Wuff", 14));
//		personen.add(new Person("Maria", "Weber", 34));
//		personen.add(new Person("Werner", "Meier", 56));
//		personen.add(new Person("Guido", "Rau", 20));
//		personen.add(new Person("Alfons", "M�ller", 13));
		
//		System.out.println(personen);
		
		
		
//		CompareToTest ct = new CompareToTest();
//		ct.compareTo("");
	}
	
	
	public int test3(MyComparator<Person> comp) {
		return 0;
	}
	
	public int compareTo(Object o) {
//		this , o
//		this.compareTo(o);
//		Liefer als int-Wert zur�ck:
//		Wert < 0, wenn this vor o in Sortierung
//		Wert > 0, wenn this nach o in Sortierung
//		Wert = 0, wenn this und o an gleicher Stelle in Sortierung
		return 0;
	}

}
