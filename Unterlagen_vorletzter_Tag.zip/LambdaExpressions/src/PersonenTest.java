import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Predicate;

public class PersonenTest {

	public static void main(String[] args) {
		List<String> namen = DemoData.createDemoNames();
		
		for(String s : namen) {
			print(s, p -> !p.isBlank() && p.contains("a"));
		}	
		System.out.println("\n==========================\n");
		
		
		List<Person> personen = DemoData.createDemoData();
		
		Predicate<Person> isAdult = person -> person.isAdult();
		Predicate<Person> isMale = person -> person.getGender() == Gender.MALE;
		Predicate<Person> isBoy = person -> person.getGender() == Gender.MALE && !person.isAdult();
		Predicate<Person> isBoy2 = (Person person) -> { return person.getGender() == Gender.MALE && !person.isAdult(); };
		Predicate<Person> isGirl = person -> person.getGender() == Gender.FEMALE && !person.isAdult();
		Predicate<Person> isWomen = person -> person.getGender() == Gender.FEMALE && person.isAdult();
		Predicate<Person> isWomenOrBoy = isWomen.or(isBoy);
		Predicate<Person> isMenOrGirl = isMale.and(isAdult).or(isGirl);
		
		System.out.println(personen);
//		personen.removeIf(isMale.or(isWomen));
//		personen.removeIf(person -> person.getGender() == Gender.MALE || (person.getGender() == Gender.FEMALE && person.isAdult()));
//		personen.removeIf(new Predicate<Person>() {
//
//			@Override
//			public boolean test(Person person) {
//				
//				return person.getGender() == Gender.MALE || (person.getGender() == Gender.FEMALE && person.isAdult());
//			}
//			
//		});

		personen.removeIf(new IsMaleOrAdultWomenChecker());
		System.out.println(personen);
	}
	
	public static void print(String s, Predicate<String> checker) {
		System.out.println(checker.test(s));
	}
	
	static class IsMaleOrAdultWomenChecker implements Predicate<Person>{

		@Override
		public boolean test(Person person) {
			return person.getGender() == Gender.MALE || (person.getGender() == Gender.FEMALE && person.isAdult());
		}
		
	}
	
	static void test() {
		Predicate<Person> isBoy2 = person -> { 
			int x = 10;
			
			return person.getGender() == Gender.MALE && !person.isAdult(); };
			
		BiFunction<Person, Integer, Integer> testBiFunction = (p, n) -> {
												int y = 0;
												switch(n) {
												case 1: y = 23;
													break;
												case 2: y = 45;
												break;
												case 3: y = 87;
												break;
												
												}
												return p.getAge() * n / y;};
	}

}
