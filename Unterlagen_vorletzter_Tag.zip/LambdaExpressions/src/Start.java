import java.util.ArrayList;
import java.util.List;

public class Start {

	public static void main(String[] args) {
		CheckTrait<Animal> checkCanHop = (a) -> {return a.canHop();};
		CheckTrait<Animal> checkCanNotHop = a -> a.canSwim();
		CheckTrait<Animal> checkCanSwim = a -> a.canSwim();
		CheckTrait<Animal> checkCanNotSwim = a -> !a.canSwim();
		
		List<Animal> animals = new ArrayList<>();
		animals.add(new Animal("fish", false, true));
		animals.add(new Animal("kangaroo", true, false));
		animals.add(new Animal("rabbit", true, false));
		animals.add(new Animal("turtle", false, true));

		print(animals, checkCanHop);
		
		
	}
	
	public static <T> void print(List<T> elements, CheckTrait<T> checker) {
		for(T a : elements) {
			if(checker.test(a)) {
				System.out.println(a);
			}
		}
	}

}
