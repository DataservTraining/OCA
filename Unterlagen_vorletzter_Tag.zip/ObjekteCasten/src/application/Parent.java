package application;

public class Parent {
	public void test() {
		System.out.println("Parent.test()");
	}
}
