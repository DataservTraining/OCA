package application;

//import java.util.ArrayList;

class MyInteger{
	private int value;

	public MyInteger(int wert) {
		super();
		this.value = wert;
	}
	
	
	public int getValue() {
		return value;
	}

	public static void t() {
		
	}
}

public class IntTest {
	
	public static void main(String[] args) {
		MyInteger mi = new MyInteger(0);
		mi.t();
		
		byte b1 = 9, b2 = 7, erg;   // Byte
		short s = 23;   //Short
		int x = 10;   // Integer
		long l = 87234878L;      //Long
		
		float f = 8.0F;     //Float
		double d = 76.9;    // Double
		
		char ch = 'A';    //Character
		boolean ok = true; // Boolean
		
		s = (short) x;
		l = (long) d;
		x = (int) d;
		
		erg = (byte) (b1 + b2);
		
//		Integer integer = Integer.valueOf(12);
		 // Integer i = new Integer(56);
		Integer i2 = 46; // Integer i = new Integer(56);
		
//		Integer ergI = i1 + i2;  
//		ergI = Integer.valueOf(i1.intValue() + i2.intValue());
//		
//		ArrayList<Integer> liste = new ArrayList<Integer>();
		Integer i1 = 56;
		Double dw = 0.25;
		Double dwErg = dw * i1;
		

	}

}
