
public class InnerInterface {
	static int x = 10;

	public static void main(String args[]) {
		int x, y;
		x = y = 100;
		Move.print();
		String s = new String("Java");
		StringBuilder sb = new StringBuilder("Java");
		StringBuilder sb0 = new StringBuilder("Java");

		if (sb.equals(sb0))
			System.out.println(" s == sb");

		InnerInterface wh = new InnerInterface();
		InnerInterface.x = 5;
//		int y = x /wh.x;
//		System.out.println(y);

		Integer integer = 9;
		switch (integer) {
		case 9:
		}

		test(new Integer[] { 3, 4, 5, 6, 7, 8 });

		x = 5;
		y = 10;
		try {
			y /= x;
		} catch (Exception e) {
			System.out.print("error");
		} finally {
			System.out.print("finally");
		}
//	     try { 
//	    	    new Whiz().meth(); 
//	    	    } catch(ArithmeticException e) { 
//	    	    System.out.print("Arithmetic"); 
//	    	    7.     } finally { 
//	    	    8.     System.out.print("final 1"); 
//	    	    9.     } catch(Exception e) { 
//	    	    10.   System.out.print("Exception"); 
//	    	    11.   } finally { 
//	    	    12.   System.out.print("final 2"); 
//	    	    13.   } 
//	    	    14.   } 
//	    	    15.   
//	    	    16.   public void meth()throws ArithmeticException { 
//	    	    17.   for(int x = 0; x < 5; x++) { 
//	    	    18.   int y = (int) 5/x; 
//	    	    19.   System.out.print(x); 
//	    	    20.   } 
//	    	    21.   } 
	}

	public static void test(Integer[] nums) {

	}

	interface Move {
		public static void main(String[] args) {
			System.out.println("Move");
		}

		public static void print() {
		}
	}

}

abstract class Test {
//	public abstract void t();
}