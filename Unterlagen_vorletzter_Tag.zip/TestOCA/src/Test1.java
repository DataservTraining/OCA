import java.time.LocalDate;
import java.time.MonthDay;
import java.time.Year;
import java.util.ArrayList;
import java.util.List;

public class Test1 {

	public static void main(String args[]) {
//		StringBuilder sb = new StringBuilder("Whizlab");
//		char[] ch = new char[4];
//		sb.getChars(1, 5, ch, 1);
//		for (char c : ch)
//			System.out.print(c);
//		
	     Year y = Year.of(2015); 
	     LocalDate date = y.atMonthDay(MonthDay.of(4,30)); 
	     System.out.println(date); 
	     
	     ArrayList<Integer> liste = new ArrayList<>();
	     
	     liste.add(1);
	     liste.add(2);
	     liste.add(3);
	     liste.add(4);
	     
	     Integer[] numbers1 = new Integer[3];
	     Integer[] numbers2 = liste.toArray(numbers1);
	     System.out.println(numbers1 == numbers2);
	     
	}

}
