
public class Test2 {

	public static void main(String[] args) {
		Double d1 = 0.0 / 0.0;

		System.out.print(Double.isNaN(d1) + " ");
		System.out.print(d1.isNaN() + " ");
		System.out.print(d1.isInfinite());

	}

}
