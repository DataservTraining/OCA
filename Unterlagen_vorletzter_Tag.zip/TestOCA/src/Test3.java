import java.io.FileNotFoundException;
import java.io.IOException;

public class Test3 {
	public static void main(int[] i) {
		System.out.print("main1");
	}

	public static void main(String... c) {
		System.out.print("main2");
	}

	public static void main(String c) {
		System.out.print("main3");
	}
	
	public static void test() {
		main("kjsadkfj");
	}
}
