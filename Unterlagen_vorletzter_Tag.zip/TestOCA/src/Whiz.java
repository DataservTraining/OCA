import java.time.Instant;

class Whiz {

	public static void main(String[] args) {
		String str = "1Z0-808";
		str = str.replace("80", "81");
		str = str.substring(str.indexOf("80"), str.lastIndexOf("80"));
		System.out.print(str);
	}

//	public static void main(String args[]) {
//		int[] a = { 1, 2, 3, 4 };
//
//		for (int j : a) {
//			if (j == 2)
//				continue;
//			for (int x = 0; 
//				 x < 3; 
//				 System.out.print(x)) {
//				x++;
//			}
//		}
//	}

//	public static void main(String args[]) {
//		
//		int x = 1;
//		assert args.length > 0 : "keine Parameter";
//		int y = new Whiz().change(x);
////		System.out.print(x + y);
//		System.out.format("%05.3f\n", 32.5);
//	}
//
//	int change(int x) {
//		x = 2;
//		return x;
//	}

//	public static void main(String[] args) {
//		char a = 67;
//		a++;
//		System.out.println(a);

//		int i = 6;
//		double d = 6.0;
//		for (int zaehler = 1; zaehler < 10000; ++zaehler) {
//			d = zaehler - 0.3;
//			d = d + 0.3;
//			if (zaehler != d)
//				System.out.printf("%d == %f ist %b\n", zaehler, d, zaehler == d);
//		}
//		System.out.println("Ende");
//		String hallo = "Hallo";
//		switch (hallo) {
//		case "hallo":
//			System.out.println(hallo);
//
//		default:
//			System.out.println("Unexpected value: " + hallo);
//		}
//		double zeit1 = 0;
//		double zeit2 = 0;
//		long start = 0;
//		long end = 0;
//		long anzahl = 100_000_000_000L;
//		int i = 0;
//		for (long z = 0; z < anzahl; ++z) {
//			i = (int) (Math.random() * 6 + 1);
//			start = System.currentTimeMillis();
//			switch (i) {
//			case 1:
//				break;
//			case 2:
//				break;
//			case 3:
//				break;
//			case 4:
//				break;
//			case 5:
//				break;
//			default:
//			}
//			end = System.currentTimeMillis();
//			zeit1 += end - start;
//
//			start = System.currentTimeMillis();
//			if (i == 1)
//				;
//			else if (i == 2)
//				;
//			else if (i == 3)
//				;
//			else if (i == 4)
//				;
//			else if (i == 5)
//				;
//			else
//				;
//
//			end = System.currentTimeMillis();
//			zeit2 += end - start;
//		}
//		System.out.println("Zeit1: " + (zeit1 / anzahl));
//		System.out.println("Zeit2: " + (zeit2 / anzahl));

}

//public class Whiz {
//	public static void main(String args[]) {
//
//		final int array[] = { 1, 2, 3 };
//
//		array = new int[9];
//		array[0] = 6;
//		
//		switch (2) {
//		case array[0]: {
//			System.out.print("A");
//		}
//		case array[1]:
//			System.out.print("B");
//		default:
//			System.out.print("default");
//			break;
//		case array[2]:
//			System.out.print("C");
//		}
//	}
//}

//public class Whiz {
//	static int x = 2;
//	static int z;
//
//	public static void main(String args[]) {
//		System.out.println(x + z);
//	}
//
//	static {
//		int x = 3;
//		z = x;
//	}
//}
//
//class Whiz {
//	
//	
//	public static void main(String args[ ]) { 
//		
//   try { 
//	   final int /** */ array[] = {2,3,4,7};
//   new Whiz().meth(); 
//   } catch(ArithmeticException e) { 
//	   final int /** */ array[] = {2,3,4,7};
//   System.out.print("Arithmetic"); 
//   } finally { 
//	   final int /** */ array[] = {2,3,4,7};
//	   System.out.print("final 1"); 
//	   } finally { 
//	   System.out.print("final 2"); 
//	   } 
//   }
//
//	public void meth() throws ArithmeticException {
//		for (int x = 0; x < 5; x++) {
//			int y = (int) 5 / x;
//			System.out.print(x);
//		}
//	}
//}