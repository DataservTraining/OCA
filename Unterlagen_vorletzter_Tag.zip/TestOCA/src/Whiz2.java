
class A{
	
}

class B extends A{
	
}

class C extends A{
	
}


public class Whiz2 {

	public static void main(String[] args) {
		A aa = new C();
		A a = new B();
		B b = (B) a;

	}

}
