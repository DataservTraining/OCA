import static java.lang.System.*;

class Foo extends Whizlabs {

	@Override
	public void test() {
		System.out.println("Foo");
	}
}

public class Whizlabs {

	static int x = 10;

	public static void main(String args[]) {
		
		
		int x = 20;
		while (x > 0) {
			do {
				x -= 2;
			} while (x > 5);
			x--;
			System.out.print(x);
		}
	}

	public void test() {
		System.out.println("Whizlabs");
	}

	public static int add(int a, int b) {
		return a + b;
	}

	public static double add(double a, double b) {
		return a + b;
	}

	 static String add(String a, String b) {
		return a + b;
	}

}