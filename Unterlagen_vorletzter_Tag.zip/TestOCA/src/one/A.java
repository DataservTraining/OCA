package one;

class A {
	protected int j = 12;
}