   
   package two; 
   
   import java.util.Arrays;

import one.*; 
   
   class B{ 
   public static void main(String [ ] args) { 
	   int[][][] array1 = new int[2][3][5];
	   int[][][] array2 = new int[2][3][5];
	   
	   for( int zeile = 0; zeile < array1.length; ++zeile) {
		   for(int spalte = 0; spalte < array1[zeile].length; ++spalte) {
			   for(int tiefe = 0; tiefe < array1[zeile][spalte].length; ++tiefe) {
			   int random = (int) (Math.random() * 100 + 1);
			   array1[zeile][spalte][tiefe] = random;
			   array2[zeile][spalte][tiefe] = random;
			   }
		   }
	   }
	   
	   System.out.println(Arrays.equals(array1, array2));
	   System.out.println(Arrays.deepEquals(array1, array2));
	   
	   Object[] obj1 = new Object[5];
	   Object[] obj2 = new Object[5];
	   
	   System.out.println(Arrays.equals(obj1, obj2));
	   System.out.println(Arrays.deepEquals(obj1, obj2));
	   
	   int[] ints1 = new int[5];
	   int[] ints2 = new int[5];
	   
	   System.out.println(Arrays.equals(ints1, ints2));
//	   System.out.println(Arrays.deepEquals(ints1, ints2));
	   
   } 
    } 