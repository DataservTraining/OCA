package arrayListProjekt;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Start {

	public static void main(String[] args) {
		ArrayList<String> liste1 = new ArrayList<>();
		ArrayList<String> liste2 = new ArrayList<>(10);
		ArrayList<String> liste3 = new ArrayList<>(liste2);
		
		List<String> liste1a = new ArrayList<>();
		List<String> liste2a = new ArrayList<>(10);
		List<String> liste3a = new ArrayList<>(liste2);
		List liste1ab = new ArrayList();
		List<Object> liste1abb = new ArrayList<>();
		
		boolean ok = liste1.add("hawk");
		System.out.println(ok);
		ok = liste1.add("hawk");
		System.out.println(ok);
		ok = liste1.add(null);
		System.out.println(ok);
		ok = liste1.add(null);
		System.out.println(ok);
//		liste1.add(Boolean.TRUE);
		liste1.add("robin");
		liste1.add(1, "blue jay");
		liste1.add(0, "cardinal");
		System.out.println(liste1);
		liste1.add(7, "Test");
		System.out.println(liste1);
		liste1.remove(4);
		
		boolean vorhanden = liste1.contains("cardinal");
		System.out.println("vorhanden? " + vorhanden);
		
		System.out.println(liste1);
		liste1.remove("cardinal");
		vorhanden = liste1.contains("cardinal");
		System.out.println("vorhanden? " + vorhanden);
		System.out.println(liste1);
		liste1.set(5, "T");
		System.out.println(liste1);
		System.out.println("L�nge der Liste: " + liste1.size());
		System.out.println("Ist Liste leer? " + liste1.isEmpty());
		liste1.clear();
		System.out.println("Ist Liste leer? " + liste1.isEmpty());
		System.out.println(liste1);
		
		List<String> one = new ArrayList<>();
		List<String> two = new ArrayList<>();
		System.out.println("\n============================\n");
		System.out.println(one.equals(two));
		one.add("a");
		System.out.println(one.equals(two));
		two.add("a");
		System.out.println(one.equals(two));
		one.add("b");
		System.out.println(one.equals(two));
		two.add(0, "b");
		System.out.println(one.equals(two));
		System.out.println(one);
		System.out.println(two);
		
		Object[] objects = liste1.toArray();
		String[] strings = liste1.toArray(new String[0]);
		
		String[] namen = {"Hans", "Fritz", "Daniel", "Sophie"};
		List<String> namensliste = Arrays.asList(namen);
		List<String> namensliste2 = Arrays.asList("Hans", "Fritz", "Daniel", "Sophie");
		System.out.println(namensliste);
		namensliste.set(0, "Willi");
		System.out.println(namensliste);
		for(String s : namen) {
			System.out.println(s);
			
		}
		System.out.println(namensliste.getClass().getName());
		System.out.println(one.getClass().getName());
		Collections.sort(namensliste);
		System.out.println(namensliste);
		
//		List<String> namensliste3 = new ArrayList<>(namensliste2);
//		namensliste3.add("Guido");
//		System.out.println(namensliste3);
		
		List<Integer> numbers = new ArrayList<>();
		numbers.add(1);
		numbers.add(2);
		System.out.println(numbers);
		numbers.remove(1);
		System.out.println(numbers);
		numbers.remove(Integer.valueOf(1));
	}
	
//	public static void test1(ArrayList<String> l) {}
//	
//	public static void test1(ArrayList<Integer> l) {}

}
